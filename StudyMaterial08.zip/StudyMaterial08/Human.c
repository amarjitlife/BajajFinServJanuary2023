#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra(){
	printf("\nBalleeee Baalleee!!! Oyeee Hoyeee!!!!");
}

void jabTakJaan() {
	printf("Jab Tak Jaan! Jaaanee Jaanaa Main Nachungi!!!");
}

void playWithHuman() {
					// Constructor Call
	Human gabbar = { 420, "Gabbar Singh", doBhangra };
	printf("\nID: %d", gabbar.id );
	printf("\nName: %s", gabbar.name );	
	gabbar.dance();
					// Constructor Call
	Human basanti = { 100, "Basanti", jabTakJaan };
	printf("\nID: %d", basanti.id );
	printf("\nName: %s", basanti.name );	
	basanti.dance();
}

int main() {
	playWithHuman();
	return 0;
}
