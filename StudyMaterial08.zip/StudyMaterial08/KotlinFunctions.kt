/**** Run Following Commands
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar
****/
package learnKotlin

fun playWithKotlinCollections() {
	val set = hashSetOf(1, 7, 53) 
	val list = arrayListOf(1, 7, 53) 
	val map = hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println(set.javaClass)
    println(list.javaClass)
    println(map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println(map.javaClass)
    println(strings.last())
    val numbers = setOf(1, 14, 2)
    println(numbers.javaClass)

    //println(numbers.max())
    println(numbers.maxOrNull())

// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.HashMap
// class java.util.LinkedHashSet
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun lastChar(string : String) = string.get( string.length - 1 )

// Extension Function
//		lastCharacter Is Extention Function Over Type String
fun String.lastCharacter() = this.get( this.length - 1 )

fun playWithLastChar() {
	println( lastChar("Hello World!") )
	println( lastChar("House No: #420") )

	println( "Hello World!".lastCharacter() )
	println( "House No: #420".lastCharacter() )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// T Is Type Placeholder
fun <T> joinToString(
	collection : Collection<T>,
	seperator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder( prefix )

	for ( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( joinToString( names ))
	println( joinToString( names, " : " ))
	println( joinToString( names, " : ", " >>>> " ))
	println( joinToString( names, " # ", " >>> ", " <<< " ))
	println( joinToString( names, " ## ", " [ ", " ] " ))

	val numbers = listOf(10, 20, 30, 40, 50)
	println( joinToString( numbers ))
	println( joinToString( numbers, " : " ))
	println( joinToString( numbers, " : ", " >>>> " ))
	println( joinToString( numbers, " # ", " >>> ", " <<< " ))
	println( joinToString( numbers, " ## ", " [ ", " ] " ))
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun <T> Collection<T>.joinToStringExtension(
        separator: String = ", ", // Default Arguments
        prefix: String = "",
        postfix: String = ""
): String {
    val result = StringBuilder(prefix)

    for ((index, element) in this.withIndex()) {
        if (index > 0) result.append(separator)
        result.append(element)
    }

    result.append(postfix)
    return result.toString()
}

fun playWithJoinToStringExtension() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.joinToStringExtension() )
	println( names.joinToStringExtension( " : " ) )
	println( names.joinToStringExtension( " : ", " >>>> " ))
	println( names.joinToStringExtension( " # ", " >>> ", " <<< " ))
	println( names.joinToStringExtension( " ## ", " [ ", " ] " ))

	val numbers = listOf(10, 20, 30, 40, 50)
	println( numbers.joinToStringExtension( ))
	println( numbers.joinToStringExtension( " : " ))
	println( numbers.joinToStringExtension( " : ", " >>>> " ))
	println( numbers.joinToStringExtension( " # ", " >>> ", " <<< " ))
	println( numbers.joinToStringExtension( " ## ", " [ ", " ] " ))
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun Collection<String>.join(
        separator: String = ", ",
        prefix: String = "",
        postfix: String = ""
) = joinToStringExtension(separator, prefix, postfix)


fun playWithJoinExtension() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.join() )
	println( names.join( " : " ) )
	println( names.join( " : ", " >>>> " ))
	println( names.join( " # ", " >>> ", " <<< " ))
	println( names.join( " ## ", " [ ", " ] " ))

	// val numbers = listOf(10, 20, 30, 40, 50)
	// println( numbers.join( ))
	// println( numbers.join( " : " ))
	// println( numbers.join( " : ", " >>>> " ))
	// println( numbers.join( " # ", " >>> ", " <<< " ))
	// println( numbers.join( " ## ", " [ ", " ] " ))
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

val String.lastChar: Char
    get() = get(length - 1)

var StringBuilder.lastChar: Char
    get() = get(length - 1)
    set(value: Char) {
        this.setCharAt(length - 1, value)
    }

fun playWithExtensionProperties() {
    println("Kotlin".lastChar)
    val sb = StringBuilder("Kotlin?")
    sb.lastChar = '!'
    println(sb)
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun parsePath(path: String) {
    val directory = path.substringBeforeLast("/")
    val fullName = path.substringAfterLast("/")

    val fileName = fullName.substringBeforeLast(".")
    val extension = fullName.substringAfterLast(".")

    println("Dir: $directory, name: $fileName, ext: $extension")
}

fun multilineTriplequotedStrings() {
	val kotlinLogo = """| //
                   .|//
                   .|/ \ """

    println(kotlinLogo.trimMargin("."))
}

fun playWithStringFunctions() {
    parsePath("/Users/yole/kotlin-book/chapter.adoc")
    multilineTriplequotedStrings()
}

//_____________________________________________________

class User(val id: Int, val name: String, val address: String)

fun saveUser(user: User) {
    if (user.name.isEmpty()) {
        throw IllegalArgumentException(
            "Can't save user ${user.id}: empty Name")
    }

    if (user.address.isEmpty()) {
        throw IllegalArgumentException(
            "Can't save user ${user.id}: empty Address")
    }

    // Save user to the database
}

fun functionValidateUser() {
//    saveUser(User(1, "", ""))
    saveUser(User(1, "Gabbar Singh", "Ramgarh"))
}

//_____________________________________________________

//class User(val id: Int, val name: String, val address: String)

fun saveUserWithLocalValidationFunction(user: User) {
	// Local Function
	//		Function Defined Inside Function
    fun validate(user: User, value: String, fieldName: String) {
        if (value.isEmpty()) {
            throw IllegalArgumentException(
                "Can't save user ${user.id}: empty $fieldName")
        }
    }

    validate(user, user.name, "Name")
    validate(user, user.address, "Address")

    // Save user to the database
}

fun functionValidateUserLocal() {
//    saveUser(User(1, "", ""))
    saveUserWithLocalValidationFunction(User(1, "Ram", "Rahim"))
}

//_____________________________________________________


fun User.validateBeforeSave() {
    fun validate(value: String, fieldName: String) {
        if (value.isEmpty()) {
            throw IllegalArgumentException(
               "Can't save user $id: empty $fieldName")
        }
    }

    validate(name, "Name")
    validate(address, "Address")
}

fun functionSaveUserLocalExtension(user: User) {
    user.validateBeforeSave()
    // Save user to the database
}

fun functionValidateUserLocalExtension() {
//    saveUser(User(1, "", ""))
    functionSaveUserLocalExtension(User(1, "Ram", "Rahim"))
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main( args: Array<String> ) {
    val list = listOf("args: ", *args)
    println(list)

	println("\nFunction : playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction : playWithLastChar")
	playWithLastChar()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoinExtension")
	playWithJoinExtension()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithStringFunctions")
	playWithStringFunctions()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
