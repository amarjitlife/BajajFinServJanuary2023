
class IntStack {
	List<Integer> data

	push ( Integer element ) {
		data.add( element )
	}

	Integer pop() {
		return data.removeLast()	
	}
}

class StringStack {
	List<String> data

	push ( String element ) {
		data.add( element )
	}

	String pop() {
		return data.removeLast()	
	}
}


// Polymorphic Code
//		Code To Generate Code
class Stack<T> {
	List<T> data

	push ( T element ) {
		data.add( element )
	}

	T pop() {
		return data.removeLast()	
	}
}


val intStack = Stack<Int>()
val stringStack = Stack<String>()


