/**** Run Following Commands
kotlinc KotlinBasics.kt -include-runtime -d basics.jar
java -jar basics.jar
****/
package learnKotlin

import java.util.TreeMap

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun helloWorld() {
	println("Hello World!");
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithTypeInferrencingAndBinding() {
	// 1. Type Inferring From RHS
	// 2. Type Binding To LHS
	//		Inferred Type Is Binded To LHS

	//In  Kotlin, Java, C, C++ 
	//		Statically Typed Langauge
	//		Type Is Compile Time Decision
	// In Python
	//		Type Is Runtime Decision

	val something = 10
	println( something )

	// Explicitly Annotating Type Of LHS As Int
	val somethingAgain: Int = 10
	println( somethingAgain )

	val something1 = 90.90
	val somethingAgain1: Double = 90.90
	println( something1 )
	println( somethingAgain1 )

	val something2 = 90.90F
	val somethingAgain2: Float = 90.90F
	println( something2 )
	println( somethingAgain2 )

	val greeting = "Good Evening!"
	val greetingAgain : String = "Good Evening!"
	println( greeting )
	println( greetingAgain )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Function Takes Two Int Arguments and Retun Int Value

fun max(a : Int, b : Int ) : Int {
	return if ( a > b ) a else b
}

// 1. Type Inferring From RHS
// 2. Type Binding To LHS
//		Inferred Type Is Binded To LHS

// Function Can Be Assigned Value/Expression
fun maximum(a : Int, b : Int ) = if ( a > b ) a else b
fun maximumAgain(a : Int, b : Int ) : Int = if ( a > b ) a else b

// fun maximum(a : Int, b : Int ) : Int = if ( a > b ) a else "Ding Dong"

fun playWithMax() {
	println( max( 100, 200 ) )
	println( max( 100, -200 ) )

	println( maximum( 100, 200 ) )
	println( maximum( 100, -200 ) )
}


//_____________________________________________________
// Creating Person Type/Class Having Two Properties
//		viz. name And isMarried
//		name Is Immutable Property
//		isMarried Is Mutable Property
class Person(val name: String, var isMarried: Boolean)

// Kotlin Compiler Will Generate Following Things
// For Above Person Class
//		1. Two Member Variable Corresponding To Each Member Property
//		2. Immutable Property Only Getter Generated
			// i.e. name Property Will Have Only Getter
//		3. Mutable Property Both Getter and Setter Generated
			// i.e. isMarried Property Will Have Both Getter and Setter
//		4. Will Generate Memberwise Initialise
//			i.e. Constructor To Intialise All The Member Properties

fun playWithPerson() {
	val gabbar = Person("Gabbar Singh", false)
	println( gabbar.name ) 		// gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

	// gabbar.name = "Gabbar Singh Decoit!"
	// println( gabbar.name )
	// KotlinBasics.kt:37:2: error: val cannot be reassigned
	// 	gabbar.name = "Gabbar Singh Decoit!"
	//  ^

// 	val : Means Immutable
//	var : Means Mutable
	val basanti = Person("Basanti", false)
	println( basanti.name )  		// basanti.getName()
	println( basanti.isMarried )	// basanti.getIsMarried()

	basanti.isMarried = true 		// basanti.setIsMarried( true )
	println( basanti.isMarried )	// basanti.getIsMarried()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Creating Rectangle Type/Class Having Three Properties
//		viz. height, width and isSquare
//		height and width Are Stored Properties
//		isSquare Is Computed Property

				// Stored Property
class Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean // Computed Property
		get() {
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle(20, 40)
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare) // Getter Getting Called

	val rectangle2 = Rectangle(200, 200)
	println( rectangle2.width )
	println( rectangle2.height )
	println( rectangle2.isSquare)
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// DESIGN PRINCIPLE
//		Design Towards Determinism Rather Than Non Determinism
//		Cover All The Cases Where Possible
//			Rather Than else Branch

// Creating Type Colour
//		Operations = Phi
//		Range = { RED, GREEN, BLUE, YELLOW }
enum class Colour {
	RED, GREEN, BLUE, YELLOW, ORANGE
}

fun getColourToString( colour : Colour ) : String {
	// when Is A Type Safe Expression
	return when ( colour ) {
		Colour.RED 		->  "Red Colour!"
		Colour.GREEN 	->  "Green Colour!"
		Colour.BLUE 	->  "Blue Colour!"
		Colour.YELLOW 	->  "Yellow Colour!"
		Colour.ORANGE 	->  "Orange Colour!"
		// else Branch Breaks Type Safety
		// else   		->  "Unknown Colour!!!"	
		// error: 'when' expression must be exhaustive, 
		// add necessary 'BLUE' branch or 'else' branch instead
	}
}

fun getStringForColor( colour : Colour ) = when ( colour ) {
	Colour.RED 		->  "Red Colour!"
	Colour.GREEN 	->  "Green Colour!"
	Colour.BLUE 	->  "Blue Colour!"
	Colour.YELLOW 	->  "Yellow Colour!"
	// Colour.YELLOW 	->  10
	Colour.ORANGE 	->  "Orange Colour!"
	// else   		->  "Unknown Colour!!!"	
}

// error: the integer literal does not conform to the expected type String
// 	Colour.YELLOW 	->  10
// fun getStringForColor1( colour : Colour ) : String = when ( colour ) {
// 	Colour.RED 		->  "Red Colour!"
// 	Colour.GREEN 	->  "Green Colour!"
// 	Colour.BLUE 	->  "Blue Colour!"
// 	Colour.YELLOW 	->  10	
// }

fun playWithColour() {
	val colour = Colour.RED
	println( colour )
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )

	println( getColourToString( Colour.RED ) )
	println( getColourToString( Colour.GREEN ) )
	println( getColourToString( Colour.BLUE ) ) 
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun mixColours(c1 : Colour, c2: Colour ) = when ( setOf(c1, c2) ) {
	setOf( Colour.BLUE, Colour.GREEN ) 	-> Colour.YELLOW
	setOf( Colour.RED, Colour.YELLOW )  -> Colour.ORANGE
	else -> throw Exception("Dirty Colour!")
	// else -> "Unknown Colour"
}

fun playWithColourMixing() {
	println( mixColours( Colour.GREEN, Colour.BLUE ) )
	println( mixColours( Colour.YELLOW, Colour.RED ) )
	// println( mixColours( Colour.GREEN, Colour.RED ) )	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

fun eval( expr: Expr ) : Int {
	// What Is Type Of expr Here?
	//		Expr
	// Checking Type Of expr Is Num
	if ( expr is Num ) { // Smart Type Casting
		//	If it True Than Type Cast To Num
		// What Is Type Of expr Here?
		//		Num
		return expr.value
	}

	// What Is Type Of expr Here?
	//		Expr
	// Checking Type Of expr Is Sum
	if ( expr is Sum ) {
		//	If it True Than Type Cast To Sum
		// What Is Type Of expr Here?
		//		Sun
		return eval( expr.left ) + eval( expr. right )
	}
	throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEval() {
	// 100 + 200
	println( eval( Sum( Num(100), Num(200) ) ) )
	// ( 100 + 200 ) + 1000
	println( eval( Sum( Sum( Num(100), Num(200) ) , Num( 1000 ) ) ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// error: type checking has run into a recursive problem. 
// 		Easiest workaround: specify types of your declarations explicitly
// fun evalIf( expr: Expr ) = if ( expr is Num ) {

fun evalIf( expr: Expr ) : Int  = if ( expr is Num ) {
		expr.value
	} else if ( expr is Sum ) {
		evalIf( expr.left ) + evalIf( expr. right )
	} else {
		throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvalIf() {
	// 100 + 200
	println( evalIf( Sum( Num(100), Num(200) ) ) )
	// ( 100 + 200 ) + 1000
	println( evalIf( Sum( Sum( Num(100), Num(200) ) , Num( 1000 ) ) ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun evalulate( expr: Expr ) : Int = when ( expr ) {
	 is Num -> expr.value
	 is Sum -> evalulate( expr.left ) + evalulate( expr. right )
	 else   -> throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEvaluate() {
	// 100 + 200
	println( evalulate( Sum( Num(100), Num(200) ) ) )
	// ( 100 + 200 ) + 1000
	println( evalulate( Sum( Sum( Num(100), Num(200) ) , Num( 1000 ) ) ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Pattern Matching
fun fizzBuzz(i: Int) = when {
    i % 15 == 0 -> "FizzBuzz "
    i % 3 == 0 -> "Fizz "
    i % 5 == 0 -> "Buzz "
    else -> "$i "
}

fun playWithFizzBuzz() {
    for (i in 1..100) { // [1, 100] Closed Interval
        print(fizzBuzz(i))
    }

    for (i in 100 downTo 1 step 2) {
        print(fizzBuzz(i))
    }
}

//_____________________________________________________

// import java.util.TreeMap

fun iteratingOverMaps() {
	val binaryRepresenation = TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresenation[ character ] = binary
	}

	for ( (letter, binary) in binaryRepresenation ) {
		println("$letter = $binary")
	}
}


//_____________________________________________________

fun isLetter(c: Char) = c in 'a'..'z' || c in 'A'..'Z'
fun isNotDigit(c: Char) = c !in '0'..'9'

fun usingInCheck() {
    println(isLetter('q'))
    println(isNotDigit('x'))
}

fun recognize(c: Char) = when (c) {
    in '0'..'9' -> "It's a digit!"
    in 'a'..'z', in 'A'..'Z' -> "It's a letter!"
    else -> "I don't know..."
}

fun usingInCheckWithWhen() {
    println(recognize('8'))
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main() {
	println("\nFunction : helloWorld"); // Semicolons Are Optional
	helloWorld()

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithPerson");
	playWithPerson()

	println("\nFunction : playWithRectangle");
	playWithRectangle()

	println("\nFunction : playWithColour");
	playWithColour()

	println("\nFunction : playWithTypeInferrencingAndBinding");
	playWithTypeInferrencingAndBinding()

	println("\nFunction : playWithColourMixing");
	playWithColourMixing()

	println("\nFunction : playWithEval");
	playWithEval()

	println("\nFunction : playWithEvalIf");
	playWithEvalIf()

	println("\nFunction : playWithEvaluate");
	playWithEvaluate()

	println("\nFunction : playWithFizzBuzz");
	playWithFizzBuzz()
	
	println("\nFunction : iteratingOverMaps");
	iteratingOverMaps()

	// println("\nFunction : ");
	// println("\nFunction : ");
	// println("\nFunction : ");
	// println("\nFunction : ");
	// println("\nFunction : ");
	// println("\nFunction : ");
}
