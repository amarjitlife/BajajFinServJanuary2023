/*
javac JavaInheritance.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaInheritance
*/
package learnJava;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Objects;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Scanner;

//_____________________________________________________

class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;
    }
    
    public final String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

//_____________________________________________________

class Manager extends Employee {
    private double bonus;
    
    public Manager(String name, double salary) {
        super(name, salary);
        bonus = 0;
    }
    
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    
    public double getSalary() { // Overrides superclass method
        return super.getSalary() + bonus;
    }
} 

class InheritanceDemo {
    public static void playWithInheritance() {
        Manager boss = new Manager("Fred", 200000);
        boss.setBonus(10000); // Defined in subclass
        System.out.println(boss.getSalary());
        boss.raiseSalary(5); // Inherited from superclass
        System.out.println(boss.getSalary());        
        
        Employee emp = boss; // Ok to convert to superclass
        emp.raiseSalary(5); // Can still apply superclass methods
        System.out.println(emp.getSalary()); // Calls Manager.getSalary
        
        if (emp instanceof Manager) {
            Manager mgr = (Manager) emp;
            mgr.setBonus(20000);
        }
    }
}

//_____________________________________________________


// import java.util.ArrayList;

class AnonymousSubclassDemo {
    public static void playWithAnonymousSubClass() {
        ArrayList<String> names = new ArrayList<String>(100) {
            public void add(int index, String element) {
                super.add(index, element);
                System.out.printf("Adding %s at %d\n", element, index);
            }
        };
        
        names.add(0, "Peter");
        names.add(1, "Paul");
        names.add(0, "Mary");
        System.out.println(names);
        
        invite( new ArrayList<String>() {{ add("Harry"); add("Sally"); }} );
    }
    
    public static void invite(ArrayList<String> friends) {
        System.out.println("Guest list: " + friends);
    }
}

//_____________________________________________________

interface Named {
    default String getName() { return ""; }
}

abstract class Person {
    private String name;

    public Person(String name) { this.name = name; }
    public final String getName() { return name; }

    public abstract int getId();
}

class Student extends Person implements Named {
    private int id;

    public Student(String name, int id) { super(name); this.id = id; }
    public int getId() { return id; }
}

class StudentDemo {
    public static void playWithAbstractClassAndInterface() {
        Person p = new Student("Fred", 1729); // OK, a concrete subclass
        System.out.println(p.getName());
        Student s = (Student) p;
        System.out.println(s.getName());
        Named n = s;
        System.out.println(n.getName());
    }
}

//_____________________________________________________

// import java.util.Objects;

class Item {
    private String description;
    private double price;
        
    public Item(String description, double price) {
        this.description = description;
        this.price = price;
    }

    public boolean equals(Object otherObject) {
        System.out.println("equals Method Called...");
        // A quick test to see if the objects are identical
        if (this == otherObject) return true;
        // Must return false if the explicit parameter is null
        if (otherObject == null) return false;
        // Check that otherObject is a Item
        if (getClass() != otherObject.getClass()) return false;
        // Test whether the instance variables have identical values
        Item other = (Item) otherObject;
        return Objects.equals(description, other.description)
            && price == other.price;
    }
    
    public int hashCode() {
        return Objects.hash(description, price);
    }

    public String toString() {
        return getClass().getName() + "[description=" + description
            + ",price=" + price + "]";
    }

}

class ItemDemo {
    public static void playWithEquality() {
        Item gabbar1 = new Item("Gabbar Singh", 50000);
        Item gabbar2 = new Item("Gabbar Singh", 50000);
        Item gabbar3 = new Item("Gabbar Singh", 500000);

        System.out.println( gabbar1 == gabbar2 );
        System.out.println( gabbar1 == gabbar3 );

        System.out.println( gabbar1.equals( gabbar2 ) );
        System.out.println( gabbar1.equals( gabbar3 ) );        
    
        System.out.println( gabbar1 ); // gabbar1.toString()
        System.out.println( gabbar3 ); // gabbar3.toString()
    }
}

//_____________________________________________________

// import java.util.Objects;

class DiscountedItem extends Item {
    private double discount;

    public DiscountedItem(String description, double price, double discount) {
        super(description, price);
        this.discount = discount;
    }

    public boolean equals(Object otherObject) {
        if (!super.equals(otherObject)) return false;
        DiscountedItem other = (DiscountedItem) otherObject;
        return discount == other.discount;
    }
    
    public int hashCode() {
        return Objects.hash(super.hashCode(), discount);
    }
}

class DiscountedItemDemo {
    public static void playWithEquality() {
        DiscountedItem gabbar1 = new DiscountedItem("Gabbar Singh", 50000, 1000);
        DiscountedItem gabbar2 = new DiscountedItem("Gabbar Singh", 50000, 1000);
        DiscountedItem gabbar3 = new DiscountedItem("Gabbar Singh", 500000, 1000);

        System.out.println( gabbar1 == gabbar2 );
        System.out.println( gabbar1 == gabbar3 );

        System.out.println( gabbar1.equals( gabbar2 ) );
        System.out.println( gabbar1.equals( gabbar3 ) );        
    }
}

//_____________________________________________________

class Human1 { }
class Student1 extends Human1  { }
class Player1 extends Student1 { }

class InheritanceDemoAgain {
    public static void playWithTypes() {
        Player1 vollyballPlayer = new Player1();

        System.out.println( vollyballPlayer instanceof Player1 );
        System.out.println( vollyballPlayer instanceof Student1 );
        System.out.println( vollyballPlayer instanceof Human1 );       

        Student1 student = new Student1();
        System.out.println( student instanceof Player1 );
        System.out.println( student instanceof Student1 );
        System.out.println( student instanceof Human1 );       
    }
}

//_____________________________________________________

enum Size {
    SMALL("S"), MEDIUM("M"), LARGE("L"), EXTRA_LARGE("XL");

    private String abbreviation;

    Size(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getAbbreviation() { return abbreviation; }
}

class EnumDemo {
    public static void playWithEnums() {
        Size notMySize = Size.valueOf("SMALL");
        System.out.println(notMySize);
        
        for (Size s : Size.values()) { System.out.println(s); }
        
        System.out.println(Size.MEDIUM.ordinal());
    }
}

//_____________________________________________________


class ClassDemo {
    public static void playWithReflection() throws ReflectiveOperationException {
        Object obj = System.out;
        Class<?> cl = obj.getClass();
        
        System.out.println("This object is an instance of " + cl.getName());

        String className = "java.util.Scanner";
        cl = Class.forName(className);
            // An object describing the java.util.Scanner class
        cl = java.util.Scanner.class;
        System.out.println(cl.getName());
        Class<?> cl2 = String[].class; // Describes the array type String[]
        System.out.println(cl2.getName());
        System.out.println(cl2.getCanonicalName());
        Class<?> cl3 = Runnable.class; // Describes the Runnable interface 
        System.out.println(cl3.getName());
        Class<?> cl4 = int.class; // Describes the int type
        System.out.println(cl4.getName());
        Class<?> cl5 = void.class; // Describes the void type
        System.out.println(cl5.getName());
    }
}

//_____________________________________________________

// import java.lang.reflect.Method;
// import java.lang.reflect.Modifier;
// import java.util.Arrays;
// import java.util.Scanner;

class MethodPrinter {
    public static void playWithClassObject() throws ReflectiveOperationException {
        System.out.print("Class name: ");
        Scanner in = new Scanner(System.in);
        String className = in.nextLine();
        Class<?> cl = Class.forName(className);
        while (cl != null) {
            for (Method m : cl.getDeclaredMethods()) { 
                System.out.println(
                    Modifier.toString(m.getModifiers()) + " " +
                    m.getReturnType().getCanonicalName() + " " +
                    m.getName() +
                    Arrays.toString(m.getParameters()));                    
            }
            cl = cl.getSuperclass();
        }
    }
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class JavaInheritance {
    public static void main( String[] args ) {
        System.out.println("\nFunction : InheritanceDemo.playWithInheritance");
        InheritanceDemo.playWithInheritance();

        System.out.println("\nFunction : AnonymousSubclassDemo.playWithAnonymousSubClass");
        AnonymousSubclassDemo.playWithAnonymousSubClass();

        System.out.println("\nFunction : StudentDemo.playWithAbstractClassAndInterface");
        StudentDemo.playWithAbstractClassAndInterface();

        System.out.println("\nFunction : ItemDemo.playWithEquality");
        ItemDemo.playWithEquality();

        System.out.println("\nFunction : DiscountedItemDemo.playWithEquality");
        DiscountedItemDemo.playWithEquality();

        System.out.println("\nFunction : InheritanceDemoAgain.playWithTypes");
        InheritanceDemoAgain.playWithTypes();

        System.out.println("\nFunction : EnumDemo.playWithEnums");
        EnumDemo.playWithEnums();

        System.out.println("\nFunction : ClassDemo.playWithReflection");
        try {
            ClassDemo.playWithReflection();
        } catch ( Exception ex ) {
            System.out.println("Found Exceptions...");
        }

        System.out.println("\nFunction : MethodPrinter.playWithClassObject");
        try {
            MethodPrinter.playWithClassObject();
        } catch ( Exception ex ) {
            System.out.println("Found Exceptions...");
        }

        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
    }
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
