_________________________________________________________________

DAY 01
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

	Assignment A3 : Coding and Experimenation Assignments
		Practice and Experiment Java Code Till Now Done!!
		
_________________________________________________________________

DAY 02
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Java Code Till Now Done!!
	
	Assignment A4 : Write Function To Calculate Factorial of Integer( Z )

_________________________________________________________________

DAY 03
_________________________________________________________________

	Assignment A1.1 : REVISION, Thinking Assignment [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A1.2 : Coding and Thinking Assignment [ MUST MUST ]
		Improve Factorial Program To Take Number From Command Line
		Explore Command Line Arguments In C
			int main( int argc, char *arg[] )

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 03 : Process Description and Control
		Chapter 01 : Computer System Overview
		Chapter 02 : Operating System Overview
		
_________________________________________________________________

DAY 04
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		https://docs.oracle.com/javase/8/docs/api/java/lang/Comparable.html
		https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 03 : Process Description and Control
		Chapter 01 : Computer System Overview
		Chapter 02 : Operating System Overview

_________________________________________________________________

DAY 05
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

_________________________________________________________________

DAY 06
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A2 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 07
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 01 : Full Chapter 
		Chapter 02 : Full Chapter
		Chapter 03 : Full Chapter
		Chapter 04 : Till Page 77 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 08
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 03 : Full Chapter
		Chapter 04 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)
		https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 09
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 04 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 08 : Streams [ MUST MUST ]
		Chapter 09 : Procesing Inputs and Outputs [ MUST ]

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!

_________________________________________________________________

DAY 10
_________________________________________________________________


_________________________________________________________________

DAY 11
_________________________________________________________________


_________________________________________________________________

DAY 12
_________________________________________________________________


_________________________________________________________________

DAY 13
_________________________________________________________________


_________________________________________________________________

DAY 14
_________________________________________________________________


_________________________________________________________________

DAY 15
_________________________________________________________________


_________________________________________________________________

DAY 16
_________________________________________________________________


_________________________________________________________________

DAY 17
_________________________________________________________________


_________________________________________________________________

DAY 18
_________________________________________________________________


_________________________________________________________________

FUTURE WORK
_________________________________________________________________


