/*
javac JavaFundamentals.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaFundamentals
*/
package learnJava;

import java.util.Random;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Scanner;
import java.util.*;
import java.time.DayOfWeek;
import java.time.LocalDate;

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Hello {
	public static void sayHello( ) {
		System.out.println("Hello World!!!!");
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class NumberDemo {
	public static void playWithNumbers() {
        System.out.println(4000000); // long literal
        System.out.println(4000000000L); // long literal
	    System.out.println(0xCAFEBABE); // hex literal
        System.out.println(0b1001); // binary literal
        System.out.println(011); // octal literal

        // Underscores in literals   
        System.out.println(1_000_000_000); 
        System.out.println(0b1111_0100_0010_0100_0000);        

        System.out.println(3.14); // double Type
        System.out.println(3.14F); // Float Type
        System.out.println(3.14); // double literal
        System.out.println(3.14D); // double literal
        System.out.println(0x1.0p-3); // hex double literal        
	
        System.out.println(1.0 / 0.0); // Infinity
        System.out.println(-1.0 / 0.0); // -Infinity
        System.out.println(0.0 / 0.0); // NaN

		// BAD CODE
        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);        
        System.out.println(0.0 / 0.0 == Double.NaN);
        // true
		// true
		// false
        // Suppose Following Values Are Coming From Somewhere Else...
        double someting = 0.0;
        double sometingElse = 0.0;

        // Huge Vulnerability!!!
        if ( someting / sometingElse == Double.NaN ) {
        	System.out.println("Don't Allow Access");
        } else {
        	System.out.println("Allow Access");        	
        }

        // GOOD CODE
        System.out.println(Double.isInfinite(1.0 / 0.0));
        System.out.println(Double.isInfinite(-1.0 / 0.0));
        System.out.println(Double.isNaN(0.0 / 0.0));
        System.out.println(Double.isFinite(0.0 / 0.0));
		// true
		// true
		// true
		// false

        someting 	 = 2.0;
        sometingElse = 1.1;
        System.out.println(2.0 - 1.1);
        // BAD PRACTICE
        //		Never Ever Compare Floating Points With Equality
        if ( someting - sometingElse == 0.9 ) {
        	System.out.println("Hi Hi!!!");
        } else {
        	System.out.println("Ho Ho!!!");
        }

        // float f1;
        // float f2;
        // // Bad Code
        // if ( f1 == f2 ) { } else {}

        // // GOOD CODE
        // if ( f1 - f2 <= Epsilon ) { } else { }

        // Character literals
        System.out.println('J'); 
        System.out.println('J' == 74); 
        System.out.println('\u004A'); 
        System.out.println('\u263A');

        // U+1F496
        // System.out.println('\u1F496');
        //2660
        System.out.println('\u2660');
        System.out.println('\u2661');
        System.out.println('\u2662');
        System.out.println('\u2663');
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.Random;

class VariableDemo {
    public static final int DAYS_PER_YEAR = 365;
    
    enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN };
    
    public static void playWithVariables() {
        int total = 0;
        int i = 0, count;
        Random generator = new Random();
        double lotsa$ = 1000000000.0; // Legal, but not a good idea
        double élévation = 0.0;
        double π = 3.141592653589793;
        String Count = "Dracula"; // Not the same as count
        int countOfInvalidInputs = 0; // Example of camelCase
        final int DAYS_PER_WEEK = 7;
        Weekday startDay = Weekday.MON;

        System.out.println( lotsa$ );
        System.out.println( élévation );
        System.out.println( π );
        System.out.println( total );
        System.out.println( Count );
        System.out.println( DAYS_PER_WEEK );                     
        System.out.println( startDay );                     
	    // System.out.println( count );  
	
        String नमस = "Hello";
        System.out.println( नमस );                     

    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class ArithmeticDemo {
    public static void playWithOperations() {
        // Division and remainder
        System.out.println(17 / 5);
        System.out.println(17 % 5);
        System.out.println(Math.floorMod(17, 5));
        
        System.out.println(-17 / 5);
        System.out.println(-17 % 5);
        System.out.println(Math.floorMod(-17, 5));
        
        // Increment and decrement
        int[] a = { 17, 29 };
        int n = 0;
        System.out.printf("%d %d\n", a[n++], n); 
        n = 0;
        System.out.printf("%d %d\n", a[++n], n);
        
        // Powers and roots
        System.out.println(Math.pow(10, 9));
        System.out.println(Math.sqrt(1000000));
        
        // Number conversions
        double x = 42;
        System.out.println(x); // 42.0
        
        float f = 123456789;
        System.out.println(f); // 1.23456792E8
        
        x = 3.75;
        n = (int) x;
        System.out.println(n); // 3
        
        n = (int) Math.round(x); 
        System.out.println(n); // 4
        
        System.out.println('J' + 1); // 75
        char next = (char)('J' + 1); 
        System.out.println(next); // 'K'
        
        n = (int) 3000000000L; 
        System.out.println(n); // -1294967296
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.math.BigDecimal;
// import java.math.BigInteger;

class BigNumberDemo {
    public static void playWithBigNumbers() {
        BigInteger n = BigInteger.valueOf(876543210123456789L);
        BigInteger k = new BigInteger("9876543210123456789");
        BigInteger r = BigInteger.valueOf(5).multiply(n.add(k)); // r = 5 * (n + k)
        System.out.println(r);
        System.out.println(2.0 - 1.1);
        BigDecimal d = BigDecimal.valueOf(2, 0).subtract(BigDecimal.valueOf(11, 1));
        System.out.println(d);
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class RelationalDemo {
    public static void playWithRelationalOperators() {
        int length = 10;
        int n = 7;
        System.out.println(0 <= n && n < length);
        
        // Short circuit evaluation
        int s = 30;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        n = 0;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        System.out.println(n == 0 || s + (1 - s) / n >= 50);
        
        int time = 7;
        System.out.println(time < 12 ? "am" : "pm");
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.time.ZoneId;
// import java.util.Arrays;

class StringDemo {
    public static void playWithStrings() {
        String location = "Java";
        String greeting = "Hello " + location;

        System.out.println(greeting);
        int age = 42;
        String output = age + " years";
        System.out.println(output);
        
        System.out.println("Next year, you will be " + age + 1); // Error
        System.out.println("Next year, you will be " + (age + 1)); // Ok
        
        String names = String.join(", ", "Peter", "Paul", "Mary");
        System.out.println(names);

        StringBuilder builder = new StringBuilder();

        for (String id : ZoneId.getAvailableZoneIds()) {
            builder.append(id);
            builder.append(", ");
        }
        String result = builder.toString();
        // System.out.println(result);
        System.out.println(result.substring(0, 200) + "...");
        System.out.println(result.length());

        // Substring
        String helloWorld = "Hello, World!";
        String world = helloWorld.substring(7, 12); // [7, 12)
        System.out.println(world);        
    
        System.out.println( world.equals("World") );
        System.out.println( world == "World" );
        System.out.println( world == "World!" );
        System.out.println( helloWorld == "Hello, World!" );
// false
// false
// true
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.Arrays;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.Collections;

class ArrayDemo {
    public static void playWithArrays() {
        String[] names = new String[10];
        // String * names = ( String * ) malloc( 10 * sizeof(String) );

        for (int i = 0; i < names.length / 2; i++) {
            names[i] = "";
        }

        System.out.println("names="+Arrays.toString(names));
        names[0] = "Fred";
        names[1] = names[0];
    
        System.out.println("names="+Arrays.toString(names));
        String[] namesAgain = names;
        System.out.println("namesAgain="+Arrays.toString(namesAgain));

        names[0] = "Gabbar Singh";
        System.out.println("names="+Arrays.toString(names));
        System.out.println("namesAgain="+Arrays.toString(namesAgain));

        int[] primes = new int[] { 2, 3, 5, 7, 11, 13 };
        int[] numbers = primes;

        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("numbers: " + Arrays.toString( numbers ));

        primes[5] = 17;
        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("numbers: " + Arrays.toString( numbers ));
    
        primes[5] = 13;
        int [] primesAgain = Arrays.copyOf( primes, primes.length );
        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("primesAgain: " + Arrays.toString( primesAgain ));

        primes[5] = 29;
        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("primesAgain: " + Arrays.toString( primesAgain ));
    }

     public static void playWithListDemo() {
        ArrayList<String> friends = new ArrayList<>();
        friends.add("Peter");
        friends.add("Paul");
        friends.remove(1);
        friends.add(0, "Paul"); // Adds before index 0

        System.out.println("friends=" + friends);

        String first = friends.get(0);
        System.out.println("first=" + first);
        friends.set(1, "Mary");

        for (int i = 0; i < friends.size(); i++) {
            System.out.println(friends.get(i));
        }

        ArrayList<String> people = friends;
        people.set(0, "Mary"); 
        System.out.println("friends=" + friends);
        
        ArrayList<String> copiedFriends = new ArrayList<>(friends);
        copiedFriends.set(0, "Fred"); 
        System.out.println("copiedFriends=" + copiedFriends);
        System.out.println("friends=" + friends);

//        ArrayList<int> something = new ArrayList<>();
        // ArrayList<Integer> something = new ArrayList<Integer>();
        ArrayList<Integer> something = new ArrayList<>();
        something.add(10);
        something.add(20);
        something.add(30);
        something.add(40);
        something.add(50);
        //something.add("DING");
        //something.add(90.9);

        for (Integer item: something) {
            System.out.println(item);
        }
        
        friends = new ArrayList<>(Arrays.asList("Peter", "Paul", "Mary"));
        String[] names = friends.toArray(new String[0]);
        
        //String[] names = friends.toArray();
        //ArrayJava.java:96: error: incompatible types: Object[] cannot be converted to String[]
        //String[] names = friends.toArray();
        

        System.out.println("names=" + Arrays.toString(names));               
        
        ArrayList<String> moreFriends = new ArrayList<>(Arrays.asList(names));
        moreFriends.add("Ding Dong");
        System.out.println("moreFriends=" + moreFriends);         
        
        Collections.reverse(friends);
        System.out.println("After reversing, friends=" + friends);
        Collections.shuffle(friends);
        System.out.println("After shuffling, friends=" + friends);
        Collections.sort(friends);        
        System.out.println("After sorting, friends=" + friends);
    }
   
    public static void swap(int[] values, int i, int j) {
        int temp = values[i];
        values[i] = values[j];
        values[j] = temp;
    }

     public static int[] firstLast(int[] values) {
        if (values.length == 0) return new int[0];
        else return new int[] { values[0], values[values.length - 1] };
    }  

    public static void arrayMethodDemo() {
        int[] fibs = { 1, 1, 2, 3, 5, 8, 11, 13 };
        swap(fibs, 2, fibs.length - 2);
        System.out.println(Arrays.toString(fibs));
        System.out.println(Arrays.toString(firstLast(fibs)));        
    }

    public static void playWithArraysAgain() {
        // Code Fill It
        // Check Arrays Are Pass By Value Or Pass By Reference
    }

    // Polymorphism
    //      Mechanism : Using Varidiac Arguments
    // Function Taking Varidiac Arguments 
    //      Variable Number of Arguments
    public static double average(String something, double... values) {
        double sum = 0;
        System.out.println(values);
        for (double v : values) sum += v;
        return values.length == 0 ? 0 : sum / values.length;
    }    

    public static double max(double first, double... rest) {
        double result = first;
        System.out.println(rest);
        for (double v : rest) result = Math.max(v, result);
        return result;
    }
    
    public static void playWithVarArgs() {
        int n = 42;
        double avg = 0;
        System.out.printf("%d\n", n);
        System.out.printf("%d %s\n", n, "widgets");
        
        double[] scores = { 3, 4.5, 10, 0 };
        avg = average("Ding Dong", scores);
        System.out.println(avg);
         avg = average("Ding Dong");
        System.out.println(avg);
         avg = average("Ding Dong", 10, 20);
        System.out.println(avg);
         avg = average("Ding Dong", 10, 20, 30, 40, 50, 60);
        System.out.println(avg);
         avg = average("Ding Dong", 10, 20, 30, 40, 50, 60, 90, 80, 999);
        System.out.println(avg);

        double largest = max(3, 4.5, 10, 0);
        System.out.println(largest);
        
        largest = max(100);
        System.out.println(largest);

        largest = max(3, 4.5, 10, 0, 100, 200, -100);
        System.out.println(largest);
        
        // avg = average("Ding Dong", 3, 4.5, 10, 0, 100, 90, 80, 70 );
        // System.out.println(avg);
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.Scanner;

class InputDemo {
    public static void playWithInputs(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("What is your name?");
        String name = in.nextLine();
        System.out.println("How old are you?");
        if (in.hasNextInt()) {
            int age = in.nextInt();
            System.out.printf("Hello, %s. Next year, you'll be %d.\n", name, age + 1);
        } else {
            System.out.printf("Hello, %s. Are you too young to enter an integer?", name);
        }
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.*;

class DoDemo {
   public static void playWithDoWhile() {
      Random generator = new Random();      
      int target = 5;
      int count = 1;
      int next;
      do {
         next = generator.nextInt(10);
         count++;
      } while (next != target);
         
      System.out.println("After " + count + " iterations, there was a values of " + target);
   }
}


//_____________________________________________________

class ForDemo {
   public static void playWithForLoop() {
      Random generator = new Random();      
      int count = 20;
      int sum = 0;
      for (int i = 1; i <= count; i++) {
         int next = generator.nextInt(10);
         sum = sum + next;         
      }
      System.out.println("After " + count 
         + " iterations, the sum is " + sum);
   }
}

//_____________________________________________________

class WhileDemo {
   public static void playWithWhileLoop() {
      Random generator = new Random();
      int sum = 0;
      int count = 0;
      int target = 90;
      while (sum < target) {
         int next = generator.nextInt(10);
         sum = sum + next;
         count++;
      }
      System.out.println("After " + count 
         + " iterations, the sum is " + sum);
   }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Greeting {
    public static void playWithCommandLineArguments(String[] args) {
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (arg.equals("-h")) arg = "Hello";
            else if (arg.equals("-g")) arg = "Goodbye";
            System.out.println(arg);
        }
    }
}


//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.time.DayOfWeek;
// import java.time.LocalDate;

class Cal {
    public static void playWithCalendar(String[] args) {
        LocalDate date = LocalDate.now().withDayOfMonth(1);
        int month;
        if (args.length >= 2) {        
            month = Integer.parseInt(args[0]);
            int year = Integer.parseInt(args[1]);
            date = LocalDate.of(year, month, 1);
        } else {
            month = date.getMonthValue();
        }
        
        System.out.println(" Mon Tue Wed Thu Fri Sat Sun");
        DayOfWeek weekday = date.getDayOfWeek();
        int value = weekday.getValue(); // 1 = Monday, ... 7 = Sunday
        for (int i = 1; i < value; i++) 
            System.out.print("    ");
        while (date.getMonthValue() == month) {
            System.out.printf("%4d", date.getDayOfMonth());
            date = date.plusDays(1);
            if (date.getDayOfWeek().getValue() == 1) 
                System.out.println();
        }
        if (date.getDayOfWeek().getValue() != 1) 
           System.out.println();
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.ArrayList;

class ReferenceDemo {
    public static void playWithObjects() {
        ArrayList<String> friends = new ArrayList<>();
        // ArrayList<String> * frineds = ( ArrayList<String> * ) malloc( );
            // friends is empty
        friends.add("Peter");
            // friends has size 1
        ArrayList<String> people = friends;
            // Now people and friends refer to the same object
        people.add("Paul");
        System.out.println(friends);
    }
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaFundamentals {
	public static void main( String[] args ) {
		System.out.println("\nFunction : Hello.sayHello");
		Hello.sayHello();

		System.out.println("\nFunction : NumberDemo.playWithNumbers");
		NumberDemo.playWithNumbers();

		System.out.println("\nFunction : VariableDemo.playWithVariables");
		VariableDemo.playWithVariables();

		System.out.println("\nFunction : ArithmeticDemo.playWithOperations");
		ArithmeticDemo.playWithOperations();

		System.out.println("\nFunction : BigNumberDemo.playWithBigNumbers");
        BigNumberDemo.playWithBigNumbers();

		System.out.println("\nFunction : RelationalDemo.playWithRelationalOperators");
        RelationalDemo.playWithRelationalOperators();

		System.out.println("\nFunction : StringDemo.playWithStrings");
        StringDemo.playWithStrings();

		System.out.println("\nFunction : ArrayDemo.playWithArrays");
        ArrayDemo.playWithArrays();

		System.out.println("\nFunction : ArrayDemo.playWithListDemo");
        ArrayDemo.playWithListDemo();

		System.out.println("\nFunction : ArrayDemo.playWithArraysAgain");
        ArrayDemo.playWithArraysAgain();

		System.out.println("\nFunction : playWithVarArgs");
        ArrayDemo.playWithVarArgs();

		System.out.println("\nFunction : InputDemo.playWithInputs");
        InputDemo.playWithInputs(args);

        System.out.println("\nFunction : Cal.playWithCalendar");
        Cal.playWithCalendar(args);

        System.out.println("\nFunction : ReferenceDemo.playWithObjects");
        ReferenceDemo.playWithObjects();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
	}
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
