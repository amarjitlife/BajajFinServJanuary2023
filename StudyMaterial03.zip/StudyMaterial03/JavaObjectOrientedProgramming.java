/*
javac JavaObjectOrientedProgramming.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaObjectOrientedProgramming
*/
package learnJava;

import java.util.Random;
import java.util.Scanner;

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}


class EvilManager {
    private String name;
    private Random generator;

    public EvilManager(String name) {
    	this.name = name;
        generator = new Random();
    }
    
    public void giveRandomRaise(Employee e) {
        double percentage = 10 * generator.nextDouble();
        e.raiseSalary(percentage);
    }
    
    public void increaseRandomly(double x) {
        double amount = x * 10 * generator.nextDouble();
        x += amount;
    }
    
    public void replaceWithZombie(Employee e) {
        e = new Employee("", 0);
    }

    public String getName() {
        return name;
    }
}

class EmployeeDemo {
    public static void playWithEmployee() {
        Employee viru = new Employee("Viru", 50000);

        viru.raiseSalary(10);
        
        System.out.println(viru.getName());
        System.out.println(viru.getSalary());

        EvilManager gabbar = new EvilManager("Gabbar Singh");
        gabbar.giveRandomRaise(viru);
        gabbar.increaseRandomly(900.0);
        System.out.println(gabbar.getName());
        System.out.println(viru.getSalary());
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class StaticMethods {
	public void sayHello() {
		System.out.println("Hello World!!! Instance Member");
	}

    public static double average(double x, double y) {
        double sum = x + y;
        return sum / 2;
    }
    
    public static void calculateAverage() {
        System.out.print("\nEnter two numbers: ");
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
        double result = average(a, b);
        System.out.println("Average: " + result);
    }
}

class StaticMethodDemo {
	public static void playWithClassMembers() {
		double average = StaticMethods.average(10, 20);
        System.out.printf("\nAverage : %f", average);

        StaticMethods.calculateAverage();
        // Compilation Error
        //	error: non-static method sayHello() cannot be referenced from 
        //	a static context
        // StaticMethods.sayHello();

        StaticMethods instance = new StaticMethods();
        instance.sayHello();

        // BAD CODING PRACTICES
        //		Type Member Must Be Accessed Using Types Only
        instance.average(100, 200);
        instance.calculateAverage();


	}
}

//_____________________________________________________

class Employee1 {
    private String name = "Gabbar Singh"; // Default Values Initialisation
    private double salary;
    private final int id;
        
    { // An initialization block

        Random generator = new Random(); 
        id = 1 + generator.nextInt(1_000_000);
    	System.out.println("Before Name Initialisation Block: " + name );
    	name = "Viru";
    	System.out.println("After Name Initialisation Block: " + name );
    }

    // Compiler Will Generate Following
    // public Employee Employee(String name, double salary) {    
    public Employee1(String name, double salary) {
    	System.out.println("Constructor Name: " + name );

    	System.out.println("Constructor Salary: " + salary );
        this.name = name;
        this.salary = salary;

        // return Employee(name, salary); Recursive Call
        // Compiler Will Generate Following
        // return this;
    	System.out.println("Constructor Name: " + name );
    }
    
    public Employee1(double salary) {
        // name already set to ""
        this.salary = salary;
    }        
    
    public Employee1(String name) {
        // salary automatically set to zero
        this.name = name;
    } 
    
    public Employee1() {
		// error: call to this must be first statement in constructor
    	// System.out.println("Constructor Name: " + name );
    	// Constructor Call
    	//		Mapped To Employee(String name, double salary)
        this("", 0); 
    	System.out.println("Constructor Name: " + name );
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }
}

class EmployeeDemo1 {
    public static void playWithEmployee() {
        Employee1 james = new Employee1("Jay", 500000);
            // calls Employee(String, double) constructor
        Employee1 anonymous = new Employee1("", 40000);
            // calls Employee(double) constructor
        Employee1 unpaid = new Employee1("Igor Intern");
        Employee1 e = new Employee1();
            // no-arg constructor
    }
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaObjectOrientedProgramming {
	public static void main( String[] args ) {
		System.out.println("\nFunction : EmployeeDemo.playWithEmployee");
		EmployeeDemo.playWithEmployee();
		
		System.out.println("\nFunction : StaticMethodDemo.playWithClassMembers");
		StaticMethodDemo.playWithClassMembers();

		System.out.println("\nFunction : EmployeeDemo1.playWithEmployee");
		EmployeeDemo1.playWithEmployee();

        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
        // System.out.println("\nFunction : ");
	}
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
