/**
 * Listing 3-9: Activity skeleton code
 */
package com.techhue.activities;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class MyActivity extends Activity {

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("MyActivity", "onCreate()");
        setContentView(R.layout.main);
    }
}
