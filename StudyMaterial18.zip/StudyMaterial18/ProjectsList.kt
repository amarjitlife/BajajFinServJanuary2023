
______________________________________

Flight Booking Application
______________________________________


1. Admin Login
	Creation, Deletion, Updating, Listing and Filtering Of Flight Data
	List Flights, Flight Details

2. User Login
	Listing and Filtering Of Flight Data
	List Flights, Flight Details

3. Flights Booking and Order
	Flights Selection, Iternary and Travellers Details Input
	Without Payment Gateway Integration

4. Rating The Services
5. Preferred Flights
______________________________________

Bus Booking Application
______________________________________


1. Admin Login
	Creation, Deletion, Updating, Listing and Filtering Of Bus Data
	List Buses, Buses Details

2. User Login
	Listing and Filtering Of Buses Data
	List Buses, Buses Details

3. Buses Booking and Order
	Buses Selection, Iternary and Travellers Details Input
	Without Payment Gateway Integration

4. Rating The Services
5. Preferred Buses

______________________________________

Shows/Movies Booking Application
______________________________________

1. Admin Login
	Creation, Deletion, Updating, Listing and Filtering Of Shows/Movies Data
	List Shows/Movies, Shows/Movies Details

2. User Login
	Listing and Filtering Of Shows/Movies Data
	List Shows/Movies, Shows/Movies Details

3. Shows/Movies Booking and Order
	Shows/Movies Selection, Iternary and Viewers Details Input
	Without Payment Gateway Integration

4. Rating The Services
5. Preferred Shows/Movies

______________________________________

Insurance Policy Booking Application
______________________________________

1. Admin Login
	Creation, Deletion, Updating, Listing and Filtering Of Insurance Data
	List Insurances, Insurance Details

2. User Login
	Listing and Filtering Of Insurances Data
	List Insurance, Insurances Details

3. Insurances Purchasing and Order
	Insurances Selection, Iternary and Buyers Details Input
	Without Payment Gateway Integration

4. Rating The Services
5. Preferred Insurances Service Providers

______________________________________

Doctors Appointments Application
______________________________________


1. Admin Login
	Creation, Deletion, Updating, Listing and Filtering Of Doctors Data
	List Doctors, Doctor Details

2. User Login
	Listing and Filtering Of Doctors Data
	List Doctor, Doctor Details

3. Doctors Apoointment and Order
	Doctors Selection, Iternary and Patient Details Input
	Without Payment Gateway Integration

4. Rating The Services
5. Preferred Doctors

