#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 

int doWork() {
	fork();
	fork();	
	printf("Hello World!...\n"); 
}

int main() { 
	doWork();
	printf("Hello World!...\n"); 

	char ch = getchar();
	return 0; 
} 
