/**** Run Following Commands
kotlinc Human.kt -include-runtime -d human.jar
java -jar human.jar
****/
package learnKotlin

interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman : Superpower {	
	override fun fly() 		 { println("Fly Like Spiderman!") }
	override fun saveWorld() { println("SaveWorld Like Spiderman!") }	
}

class Superman: Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }	
}

class Heman : Superpower {
	override fun fly() 		 { println("Fly Like Heman!") }
	override fun saveWorld() { println("SaveWorld Like Heman!") }	
}

class Wonderwoman : Superpower {
	override fun fly() 		 { println("Fly Like Wonderwoman!") }
	override fun saveWorld() { println("SaveWorld Like Wonderwoman!") }	
}

class Human 
{
	var power: Superpower? = null // New Thing
	fun fly() 		 { power?.fly() } 		// super.fly() }
	fun saveWorld()  { power?.saveWorld() } // super.saveWorld }
}

												// Delegate
class HumanNew(power: Superpower) : Superpower by power
// Compiler Will Generate Following Code 
// {
// 	var power: Superpower = power() 		// New Thing
// 	fun fly() 		 { power.fly() } 		
// 	fun saveWorld()  { power.saveWorld() }  
// }

fun main() {
	val h = Human()
	h.power = Spiderman()
	h.fly()
	h.saveWorld()

	h.power = Superman()
	h.fly()
	h.saveWorld()

	h.power = Heman()
	h.fly()
	h.saveWorld()

	h.power = Wonderwoman()
	h.fly()
	h.saveWorld()

	println("\nNew Human... Delegate Property")
	val hn = HumanNew( Spiderman() )
	hn.fly()
	hn.saveWorld()
}
