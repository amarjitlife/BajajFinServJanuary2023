/**** Run Following Commands
kotlinc KotlinYeDilMangeMore.kt -include-runtime -d more.jar
java -jar basics.jar
****/
package learnKotlin

import java.util.HashSet
import java.util.Random

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Gabbar {
	// Using companion object
	//		Create Type Members
	//		i.e. Accessed Using Type
	companion object {
		fun doSomething() {
			println("Companion Object doSomething Called...")
		}

		fun doSomethingMore() {
			println("Companion Object doSomethingMore Called...")
		}
	}

	// error: only one companion object is allowed per class
	// companion object {
	// 	fun foo() = println("Foooooo")
	// }
}

fun playWithCompanionObject() {
	Gabbar.doSomething()
	Gabbar.doSomethingMore()

	// Gabbar.companion.doSomething()
	// Gabbar.companion.doSomethingMore()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

//import java.util.HashSet

class CountingSet<T>( val innerSet: MutableCollection<T> = HashSet<T>() ) 
    : MutableCollection<T> by innerSet {

    var objectsAdded = 0

    // Custom Implementation	
    override fun add(element: T): Boolean {
        objectsAdded++
        return innerSet.add(element)
    }

    override fun addAll(elements: Collection<T>): Boolean {
        objectsAdded += elements.size
        return innerSet.addAll(elements)
    }

    // Compiler Will Generate Following Code
    // override fun removeAll(elements: Collection<T>): Boolean {
    //     return innerSet.removeAll(elements)
    // }

    // override fun remove(elements: Collection<T>): Boolean {
    //     return innerSet.remove(elements)
    // }

}

fun playWithByDelegation() {
    val countingSet = CountingSet<Int>()
    countingSet.addAll(listOf(1, 1, 2))
    println("${countingSet.objectsAdded} objects added...")
    println("${countingSet.size} remain...")

    // countingSet.removeAll()
    // println("${countingSet.objectsAdded} objects added...")
    // println("${countingSet.size} remain...")
}

//_____________________________________________________

data class Email(val from: String, val to: String, val title: String)


fun loadEmails( name: String ) : List<Email> {
	println("Loading Emails Of : $name")
	val emails = listOf( 
		Email("gabbar@gmail.com", "samba@gmail.com", "Kitna Enam Rakhe Hai Sarkar!"),
		Email("gabbar@gmail.com", "samba@gmail.com", "Kya Kiya Jayee!"),
		Email("gabbar@gmail.com", "thakur@gmail.com", "Ye Haat Mujhe Dede Thakur!"),	
		Email("gabbar@gmail.com", "kalia@gmail.com", "Kitne Aadmi Thee"),		
	)
	return emails
}

class PersonLazy1(val name: String) {
	private var _emails: List<Email>? = null
	// private var _emails: List<Email>? = loadEmails(name)

	val emails: List<Email>
		get() {
			// Lazy Pattern : Lazily Loading
			//		Load Emails Only When Used
			if ( _emails == null ) { 
				_emails = loadEmails(name)
			}
			return _emails!!
		}
		// get() { return _emails ?: listOf() }
}

class PersonLazy2(val name: String) {
	val emails by lazy { loadEmails(name) }
	// Compiler Will Generate Following Code For Above Line Of Code
	// private var _emails: List<Email>? = loadEmails(name)
	// val emails: List<Email>
		// get() {
		// 	// Lazy Pattern : Lazily Loading
		// 	//		Load Emails Only When Used
		// 	if ( _emails == null ) { 
		// 		_emails = loadEmails(name)
		// 	}
		// 	return _emails!!
		// }
}

fun playWithPerson() {
	val gabbar1 = PersonLazy1(name = "Gabbar Singh")
	println( gabbar1.emails )

	val gabbar2 = PersonLazy2(name = "Gabbar Singh")
	println( gabbar2.emails )
}

//_____________________________________________________

// Polymorphic Function
// 		Function With Default Arguments
fun <T> Collection<T>.joinToStringFinal(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder( prefix ) // Java StringBuilder
	// collections.withIndex() Will Generate List Of Tuples
	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringFinal() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( list.joinToStringFinal( " ; ", "( ", " )" ) )
	println( list.joinToStringFinal( ) )
	println( list.joinToStringFinal( " : ") )
	println( list.joinToStringFinal( " : ", "[ " ) )
	println( list.joinToStringFinal( " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.joinToStringFinal( " ; ", "( ", " )" ) )
	println( names.joinToStringFinal(  ) )	
	println( names.joinToStringFinal( " : " ) )	
	println( names.joinToStringFinal( " : ", "[ " ) )	
	println( names.joinToStringFinal( " : ", "[ ", " ]" ) )	
}

//_____________________________________________________

// E Is Type Place Holder
// MutableStack Is Generic Type i.e. Template

//	Generics Are Templates Programming
//		In Mathematics It's Callled Parameterised Types
//		Write Code To Generate Code
//		Compile Time Polymorphism

class MutableStack<E>( vararg items: E ) {              
	private val elements = items.toMutableList()
	fun push(element: E) = elements.add(element)        
	fun peek(): E = elements.last()                     
	fun pop(): E = elements.removeAt(elements.size - 1)
	fun isEmpty() = elements.isEmpty()
	fun size() = elements.size
	override fun toString() = "MutableStack(${elements.joinToString()})"
}


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<Int>( vararg items: Int ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: Int) = elements.add(element)        // 2
//   fun peek(): Int = elements.last()                     // 3
//   fun pop(): Int = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<String>( vararg items: String ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: String) = elements.add(element)        // 2
//   fun peek(): String = elements.last()                     // 3
//   fun pop(): String = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

fun playWithMutableStack() {
	// Type Inferred and Substitued At Type Place Holder <E> At Compile Time
	val stackInts = MutableStack<Int>( 10, 20, 30 )
	println( stackInts.size() ) 
	stackInts.push( 100 )
	stackInts.push( 200 )
	println( stackInts.size() ) 
	println( stackInts.pop() )	

	val stackStrings = MutableStack<String>( "Ding", "Dong" )
	println( stackStrings.size() ) 
	stackStrings.push( "Ting" )
	stackStrings.push( "Tong" )
	println( stackStrings.size() ) 
	println( stackStrings.pop() )	
}


//_____________________________________________________


class Temperature(var tempInCelsius: Float)

// Extension Properties 
var Temperature.tempInFahrenheit: Float
    get() = (tempInCelsius * 9 / 5) + 32
    set(value) {
        tempInCelsius = (value - 32) * 5 / 9
    }

fun playWithExtensionProperties() {
    val temp = Temperature(32f)
	println( temp.tempInFahrenheit )

	temp.tempInFahrenheit = 90f
	println( temp.tempInCelsius )
}
//_____________________________________________________

// Generic Extention Property

val <T> List<T>.penultimate: T
	get() = this[ size - 2 ]


fun playWithGenericProperty() {
	val list = listOf( 10, 20, 30, 40)
	println( "Value : ${ list.penultimate }")

	val listAgain = listOf( "Ding", "Dong", "Ting", "Tong")
	println( "Value : ${ listAgain.penultimate }")
}

//_____________________________________________________

open class Animal( val type : String  ) 
open class Pet( val name : String, type: String ) : Animal( type )

class Cat( name : String, type: String ) : Pet( name, type ) 
open class Dog( name : String, type: String ) : Pet( name, type ) 
class GermanShaperd( name : String, type: String ) : Dog( name, type ) 

fun chooseFavoriteNonGeneric( pets: List<Pet> ) : Pet {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun <T : Pet> chooseFavorite(pets: List<T> ): T {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun playWithChooseFavorite() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favorite = chooseFavorite( cats )
	println( "Favorite Name : ${ favorite.name }" )

	val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favoriteAgain = chooseFavoriteNonGeneric( catsAgain )
	println( "Favorite Name : ${ favoriteAgain.name }" )

	val animals: List<Animal> = listOf( Animal("Fish"), Animal("Bird"), Animal("Mammal") )
	for (animal in animals) println( animal.type )
 	// error: type mismatch: inferred type is Animal but Pet was expected
	// val favoriteAgain = chooseFavorite( animals )
	// print( favoriteAgain )
}

//_____________________________________________________

// Boundless Generic Function
//		i.e. T Place Holder Can Be Substited With Any Type T
fun <T> equalsResult( first: T, second : T ) : Boolean  {
	return first == second
}

fun playWithEqualResults() {
	val first0 = 10
	val second0 = 100
	println( equalsResult( first0, second0 ) )

	val first1 = 10.90
	val second1 = 100.90
	println( equalsResult( first1, second1 ) )

	val first2 = Cat("Catie", "Cat")
	val second2 = Cat("Batie", "Cat")
	println( equalsResult( first2, second2 ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun < T : Comparable<T> > max( first: T, second : T ) : T {
	return if ( first > second ) first else second
}

fun playWithGenericMax() {
	val maxValue0 = max( "Kotlin", "Java" )
	println( maxValue0 )

	val maxValue1 = max( 900, 100 )
	println( maxValue1 )

	val maxValue2 = max( 90.90, 100.100 )
	println( maxValue2 )
}

//_____________________________________________________

open class Human( val name: String )
class Owner( name : String ) : Human( name )

// Mutiple Type Parameters viz. T and U
fun < T : Pet, U : Human > chooseFavoriteMultiples( pets: List<T>, owners : List<U> ) : T {
	val random = Random()
	val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

fun playWithChooseFavoriteMultiples() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val owners: List<Owner> = listOf( Owner("Himnanshu"), Owner("Shubra") )

	val favorite = chooseFavoriteMultiples( cats, owners )
	println( "Favorite Name : ${ favorite.name }" )
}

//_____________________________________________________


// // Default Constraint
// // If you don’t specify a constraint, the default constraint will be Any?.
// fun <T> chooseFavoriteDefault(things: List<T>) : T { 
// 	/* ... */ 
// }

// // is the exactly the same as
// fun <T : Any?> chooseFavoriteDefaultAgain(things: List<T>) : T { 
// 	/* ... */ 
// }

// // Nullable Constraints
// // If you want to specify a nullable type for the constraint, 
// // it’ll work as expected:

// fun <T : Pet?> chooseFavoriteNullablePet(pets: List<T>): T {
//     val favorite = pets[random.nextInt(pets.size)]
//     println("${favorite?.name ?: "Nobody"} is the favorite")
//     return favorite
// }

// // Any Non-Null
// // Naturally, if you want to accept any type that isn’t null, 
// // you’d just use Any as the constraint:

// fun <T : Any> chooseFavoriteNonNullableAny(things: List<T>): T { 
// 	/* ... */ 
// }

// fun playWithChooseFavoriteNullable() {
// 	val maybeCats: List<Cat?> = listOf(Cat("Whiskers"), null, Cat("Rosie"))
// 	val favorite: Cat? = chooseFavorite(maybeCats)

// 	// Just remember that the ? goes on the type constraint, 
// 	// not the type parameter references. 
// 	// In other words, in this example, you 
// 	// wouldn’t specify List<T?> or return T?.
// }


//_____________________________________________________

// Function Type
//		( (StringBuilder) -> Unit ) -> String
fun buildString( builderAction: (StringBuilder) -> Unit ) : String {
    val sb = StringBuilder()
    builderAction(sb)
    return sb.toString()
}

fun playWithBuildString() {
    val something = buildString {
        it.append("Hello, ")
        it.append("World!")
    }

    println(something)
}

//_____________________________________________________

// Lambda With Receiver Type
								//Reciever Type. Lambda
fun createString( builderAction: StringBuilder.() -> Unit ) : String {
    val sb = StringBuilder()
    builderAction(sb)
    return sb.toString()
}

fun playWithCreateString() {
    val something = createString {
        // this.append("Hello, ")
        append("World!")
        append("World!")
        append("World!")
    }

    println(something)
}

//_____________________________________________________


open class Tag(val name: String) {
    private val children = mutableListOf<Tag>()
    protected fun <T : Tag> doInit(child: T, init: T.() -> Unit) {
        child.init()
        children.add(child)
    }
    override fun toString() ="<$name>${children.joinToString("")}</$name>"
}

fun table(init: TABLE.() -> Unit) = TABLE().apply(init)

class TABLE : Tag("table") {
    fun tr(init: TR.() -> Unit) = doInit(TR(), init)
}
class TR : Tag("tr") {
    fun td(init: TD.() -> Unit) = doInit(TD(), init)
}
class TD : Tag("td")

fun createTable() =
    table {
        tr {
            td {
            }
        }
    }

fun playWithCreateTables() {
    println(createTable())
}

//_____________________________________________________
//_____________________________________________________


// package learnJava;

// import java.io.Serializable;

// class OuterSer implements Serializable {
// 	private int rank;
// 	class InnerSer implements Serializable {
// 		protected String name;
// 			// ...
// 	}
// }


//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main() {
	println("\nFunction : playWithCompanionObject")
	playWithCompanionObject()

	println("\nFunction : playWithByDelegation")
	playWithByDelegation()

	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithJoinToStringFinal")
	playWithJoinToStringFinal()

	println("\nFunction : playWithChooseFavorite")
	playWithChooseFavorite()

	println("\nFunction : playWithChooseFavoriteMultiples")
	playWithChooseFavoriteMultiples()

	println("\nFunction : playWithBuildString")
	playWithBuildString()

	println("\nFunction : playWithCreateString")
	playWithCreateString()

	println("\nFunction : playWithCreateTables")
	playWithCreateTables()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
