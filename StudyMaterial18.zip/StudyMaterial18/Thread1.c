#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

void * subRoutine1( void * dataAddress ) {
	int data = *((int *) dataAddress);	
	for ( int i = data ; i > 0 ; i-- ) 
		printf("On Thread1 : Doing Something: %d\n", i) ;
	return dataAddress;
}

void * subRoutine2( void * dataAddress ) {
	int data = *((int *) dataAddress);
	for ( int i = data ; i > 0 ; i-- ) 
		printf("On Thread2 : Doing Something: %d\n", i) ;
	return dataAddress;
}

int main() { // Main Thread
	pthread_t Thread1, Thread2;
	int result1, result2;

	int data1 = 5;
	int data2 = 3;
	result1 = pthread_create( &Thread1, NULL, *subRoutine1, (void *) &data1 );	
	result2 = pthread_create( &Thread2, NULL, *subRoutine2, (void *) &data2 );

	printf("Thread1 Result: %d\n", result1);
	printf("Thread2 Result: %d\n", result2);

	for ( int i = 0 ; i < 5 ; i++ ) 
		printf("Main Thread... %d\n", i);	

	sleep( 5 );
	return 0;
}

