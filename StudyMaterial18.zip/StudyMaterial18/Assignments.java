_________________________________________________________________

DAY 01
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

	Assignment A3 : Coding and Experimenation Assignments
		Practice and Experiment Java Code Till Now Done!!
		
_________________________________________________________________

DAY 02
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Java Code Till Now Done!!
	
	Assignment A4 : Write Function To Calculate Factorial of Integer( Z )

_________________________________________________________________

DAY 03
_________________________________________________________________

	Assignment A1.1 : REVISION, Thinking Assignment [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A1.2 : Coding and Thinking Assignment [ MUST MUST ]
		Improve Factorial Program To Take Number From Command Line
		Explore Command Line Arguments In C
			int main( int argc, char *arg[] )

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 03 : Process Description and Control
		Chapter 01 : Computer System Overview
		Chapter 02 : Operating System Overview
		
_________________________________________________________________

DAY 04
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		https://docs.oracle.com/javase/8/docs/api/java/lang/Comparable.html
		https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 03 : Process Description and Control
		Chapter 01 : Computer System Overview
		Chapter 02 : Operating System Overview

_________________________________________________________________

DAY 05
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

_________________________________________________________________

DAY 06
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A2 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 07
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 01 : Full Chapter 
		Chapter 02 : Full Chapter
		Chapter 03 : Full Chapter
		Chapter 04 : Till Page 77 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 08
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 03 : Full Chapter
		Chapter 04 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)
		https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 09
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 04 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 08 : Streams [ MUST MUST ]
		Chapter 09 : Procesing Inputs and Outputs [ MUST ]

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!

_________________________________________________________________

DAY 10
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 05 : Full Chapter 
		Chapter 06 : Full Chapter 
		Chapter 07 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 08 : Streams [ MUST MUST ]

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!

_________________________________________________________________

DAY 11
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 05 : Full Chapter 
		Chapter 06 : Full Chapter 
		Chapter 07 : Full Chapter 
		Chapter 08 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 08 : Streams [ MUST MUST ]

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!

_________________________________________________________________

DAY 12
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 06 : Full Chapter 
		Chapter 07 : Full Chapter 
		Chapter 08 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!


_________________________________________________________________

DAY 13
_________________________________________________________________

	AndroidCode A1 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial12.1.zip And Unzip It!

		Explore Code
			All .java And .xml Files In Following Projects
			└── StudyMaterial12.1
			    └── Android.Code01.1
			        ├── ActivitiesJava
			        ├── ConfigChangesJava
			        ├── ManifestAndResourcesJava


	AndroidCode A2 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial12.2.zip And Unzip It!

			 ├── StudyMaterial12.2
				│ └── Android.Code02.1
				│     ├── Project.04.01.Layouts
				│     ├── Project.04.03.Views
				│     ├── Project.04.04.Adapters

	Coding Assignment CA3 : 
		Write Good And Working Code In Kotlin 
			For Following Android Examples
		
		    └── Android.Code01.1
		        ├── ActivitiesJava

		 Create New Project
		 	Language : Kotlin
		 	minSdk : 28

	Coding Assignment CA4 : 
		Write Good And Working Code In Kotlin 
			For Following Android Examples

		    └── Android.Code01.1
		        ├── ConfigChangesJava
		        ├── ManifestAndResourcesJava

			└── Android.Code02.1
			     ├── Project.04.01.Layouts
			     ├── Project.04.03.Views
						       
	Assignment RA1 : Reading and Thinking Assignment [ MUST MUST ]		
		https://developer.android.com/guide/components/fundamentals
		
_________________________________________________________________

DAY 14
_________________________________________________________________

	AndroidCode A2 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial12.2.zip And Unzip It!

			 ├── StudyMaterial12.2
				│ └── Android.Code02.1
				│     ├── Project.04.04.Adapters

	Coding Assignment CA1 : 
		Write Good And Working Code In Kotlin 
			For Following Android Examples

			 ├── StudyMaterial12.2
				 └── Android.Code02.1
				     ├── Project.04.04.Adapters

	Coding Assignment CA2 : 
		Write Good And Working App Code In Kotlin
			Flowers App
				- List Flowers With Images And Names
				- Structure Your Code In MVC Architecture
				- Create Model, View and Controller Classes/Files

	Coding Assignment CA3 : 
		Write Good And Working App Code In Kotlin
			AndroidIntroduction Example

	Assignment RA1 : Reading and Thinking Assignment [ MUST MUST ]		
		https://developer.android.com/guide/components/fundamentals
		https://guides.codepath.com/android/Activity-Lifecycle		
		https://developer.android.com/guide/components/activities/intro-activities
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/components/activities/state-changes
		https://developer.android.com/guide/components/activities/tasks-and-back-stack

		https://developer.android.com/guide/topics/resources/providing-resources
		https://developer.android.com/guide/topics/resources/runtime-changes
		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
		https://guides.codepath.com/android/Using-the-RecyclerView

	GitHub Project Naming Guilelines
		Parent GIT Repository Name: LearnAndroid
			After That Each Directory Is Android Project

			LearnAndroid
				LayoutKotlin
				ConfigChangesKotlin
				ViewKotlin
				FlowersAppKotlin
				AndroidIntroductionKotlin

_________________________________________________________________

DAY 15
_________________________________________________________________

	Coding Assignment CA1 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
		https://guides.codepath.com/android/Using-the-RecyclerView

		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/fragments#:~:text=A%20Fragment%20represents%20a%20reusable,an%20activity%20or%20another%20fragment.
		https://developer.android.com/guide/fragments/fragmentmanager
		https://developer.android.com/guide/fragments/transactions
		https://developer.android.com/guide/fragments/lifecycle
		https://developer.android.com/guide/fragments/saving-state
		https://developer.android.com/guide/fragments/communicate

	AndroidCode A1 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial14.1.zip And Unzip It!

		├── StudyMaterial14.1
			 ├── Project.05.01.Intents

	AndroidCode A2 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial14.1.zip And Unzip It!

		├── StudyMaterial14.1
			 ├── Project.05.02.Linkify
			 └── Project.05.03.BroadcastIntents

	Coding Assignment CA1 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial14.2.zip And Unzip It!

		├── StudyMaterial14.2
		│ └── Android.Code.Fragments
		│     ├── AndroidFragmentFundamentals
		│     ├── AndroidFragmentPizza


	Coding Assignment CA2: Pune Warriors
		Select Guns and Horses
		Use RecylerView and Fragments

_________________________________________________________________

DAY 16
_________________________________________________________________


	Reading Assignment RA1 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
		https://guides.codepath.com/android/Using-the-RecyclerView

		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/fragments#:~:text=A%20Fragment%20represents%20a%20reusable,an%20activity%20or%20another%20fragment.
		https://developer.android.com/guide/fragments/fragmentmanager
		https://developer.android.com/guide/fragments/transactions
		https://developer.android.com/guide/fragments/lifecycle
		https://developer.android.com/guide/fragments/saving-state
		https://developer.android.com/guide/fragments/communicate

		https://developer.android.com/guide/components/services

	Coding Assignment CA1 : Write Good And Working App Code In Kotlin!
		Code Following AndroidFragmentPizza Code In Kotlin

		├── StudyMaterial14.2
		│ └── Android.Code.Fragments
		│     ├── AndroidFragmentPizza


	AndroidCode A2 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial15.1.zip And Unzip It!

		├── StudyMaterial15.1
		│	└── Android.Code.Services
		│		├── AndroidServicesDemo
		│		└── Project.09.01.MyService


	Coding Assignment CA2: Pune Warriors Game
		Select Guns and Horses
		Use ListView/RecylerView and Fragments
		Show Selected Horses and Guns In First Screen


	[ MUST MUST MUST MUST COMPLETE IT BY 30TH JANUARY MONDAY MORNING!!! ]
	Coding, Reading and Reasongin Assignment CA3: Google Anroid Codelab
		Android Developer Fundamentals [ MUST MUST MUST ]
		https://developer.android.com/courses/fundamentals-training/toc-v2

		COMPLETE ALL UNITS!!!

		Build your first app
		1.1: Android Studio and Hello World
		1.2 Part A: Your first interactive UI
		1.2 Part B: The layout editor
		1.3: Text and scrolling views
		1.4: Learn to help yourself

		Lesson 2: Activities and intents

		2.1: Activities and intents
		2.2: Activity lifecycle and state
		2.3: Implicit intents
		
		Lesson 3: Testing, debugging, and using support libraries

		3.1: The debugger
		3.2: Unit tests
		3.3: Support libraries
		
		Unit 2: User experience
		Lesson 4: User interaction

		4.1: Clickable images
		4.2: Input controls
		4.3: Menus and pickers
		4.4: User navigation
		4.5: RecyclerView
		
		Lesson 5: Delightful user experience

		5.1: Drawables, styles, and themes
		5.2: Cards and colors
		5.3: Adaptive layouts
		
		Lesson 6:Testing your UI

		6.1: Espresso for UI testing
		Unit 3: Working in the background
		
		Lesson 7: Background tasks

		7.1: AsyncTask
		7.2: AsyncTask and AsyncTaskLoader
		7.3: Broadcast receivers
		
		Lesson 8: Alarms and schedulers

		8.1: Notifications
		8.2: The alarm manager
		8.3: JobScheduler
		
		Unit 4: Saving user data
		
		Lesson 9: Preferences and settings

		9.1: Shared preferences
		9.2: App settings

		Lesson 10: Storing data with Room

		10.1 Part A: Room, LiveData, and ViewModel
		10.1 Part B: Deleting data from a Room database


	Reference Material:
		Android Programming: The Big Nerd Ranch Guide, 4th Edition
		Refer It's Souce Code

_________________________________________________________________

DAY 16 + SUNDAY : HOME WORK
_________________________________________________________________

	Reading Assignment RA1 : Coding, Reading and Thinking Assignment [ MUST MUST ]		
		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
		https://guides.codepath.com/android/Using-the-RecyclerView

		https://developer.android.com/reference/android/content/Intent
		https://developer.android.com/guide/components/intents-filters
		https://developer.android.com/guide/fragments#:~:text=A%20Fragment%20represents%20a%20reusable,an%20activity%20or%20another%20fragment.
		https://developer.android.com/guide/fragments/fragmentmanager
		https://developer.android.com/guide/fragments/transactions
		https://developer.android.com/guide/fragments/lifecycle
		https://developer.android.com/guide/fragments/saving-state
		https://developer.android.com/guide/fragments/communicate

		https://developer.android.com/guide/components/services

	Coding Assignment CA2: Pune Warriors Game
		Select Guns and Horses
		Use ListView/RecylerView and Fragments
		Show Selected Horses and Guns In First Screen


	[ MUST MUST MUST MUST COMPLETE IT BY 30TH JANUARY MONDAY MORNING!!! ]
	Coding, Reading and Reasongin Assignment CA3: Google Anroid Codelab
		Android Developer Fundamentals [ MUST MUST MUST ]
		https://developer.android.com/courses/fundamentals-training/toc-v2

		COMPLETE ALL UNITS!!!

		Build your first app
		1.1: Android Studio and Hello World
		1.2 Part A: Your first interactive UI
		1.2 Part B: The layout editor
		1.3: Text and scrolling views
		1.4: Learn to help yourself

		Lesson 2: Activities and intents

		2.1: Activities and intents
		2.2: Activity lifecycle and state
		2.3: Implicit intents
		
		Lesson 3: Testing, debugging, and using support libraries

		3.1: The debugger
		3.2: Unit tests
		3.3: Support libraries
		
		Unit 2: User experience
		Lesson 4: User interaction

		4.1: Clickable images
		4.2: Input controls
		4.3: Menus and pickers
		4.4: User navigation
		4.5: RecyclerView
		
		Lesson 5: Delightful user experience

		5.1: Drawables, styles, and themes
		5.2: Cards and colors
		5.3: Adaptive layouts
		
		Lesson 6:Testing your UI

		6.1: Espresso for UI testing
		Unit 3: Working in the background
		
		Lesson 7: Background tasks

		7.1: AsyncTask
		7.2: AsyncTask and AsyncTaskLoader
		7.3: Broadcast receivers
		
		Lesson 8: Alarms and schedulers

		8.1: Notifications
		8.2: The alarm manager
		8.3: JobScheduler
		
		Unit 4: Saving user data
		
		Lesson 9: Preferences and settings

		9.1: Shared preferences
		9.2: App settings

		Lesson 10: Storing data with Room

		10.1 Part A: Room, LiveData, and ViewModel
		10.1 Part B: Deleting data from a Room database


	Reference Material:
		Android Programming: The Big Nerd Ranch Guide, 4th Edition
		Refer It's Souce Code

_________________________________________________________________

DAY 17
_________________________________________________________________

	[ MUST MUST MUST MUST COMPLETE IT BY 30TH JANUARY MONDAY MORNING!!! ]
	Assignment CA1: Google Anroid Codelab
		Coding, Reading and Reasong
		Android Developer Fundamentals [ MUST MUST MUST ]
		https://developer.android.com/courses/fundamentals-training/toc-v2

		COMPLETE ALL UNITS!!!

		Build your first app
		1.1: Android Studio and Hello World
		1.2 Part A: Your first interactive UI
		1.2 Part B: The layout editor
		1.3: Text and scrolling views
		1.4: Learn to help yourself

		Lesson 2: Activities and intents

		2.1: Activities and intents
		2.2: Activity lifecycle and state
		2.3: Implicit intents
		
		Lesson 3: Testing, debugging, and using support libraries

		3.1: The debugger
		3.2: Unit tests
		3.3: Support libraries
		
		Unit 2: User experience
		Lesson 4: User interaction

		4.1: Clickable images
		4.2: Input controls
		4.3: Menus and pickers
		4.4: User navigation
		4.5: RecyclerView
		
		Lesson 5: Delightful user experience

		5.1: Drawables, styles, and themes
		5.2: Cards and colors
		5.3: Adaptive layouts
		
		Lesson 6:Testing your UI

		6.1: Espresso for UI testing
		Unit 3: Working in the background
		
		Lesson 7: Background tasks

		7.1: AsyncTask
		7.2: AsyncTask and AsyncTaskLoader
		7.3: Broadcast receivers
		
		Lesson 8: Alarms and schedulers

		8.1: Notifications
		8.2: The alarm manager
		8.3: JobScheduler
		
		Unit 4: Saving user data
		
		Lesson 9: Preferences and settings

		9.1: Shared preferences
		9.2: App settings

		Lesson 10: Storing data with Room

		10.1 Part A: Room, LiveData, and ViewModel
		10.1 Part B: Deleting data from a Room database


	READING ASSSIGNMENT RA1 : [MUST MUST MUST]
		ANDROID APPLICATION MODERN ARCHITECHURE AND THINKING ASSIGNMENT
		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/topic/architecture/intro
		https://developer.android.com/topic/architecture
		https://developer.android.com/topic/architecture/ui-layer
		https://developer.android.com/topic/architecture/ui-layer/events
		https://developer.android.com/topic/architecture/domain-layer
		https://developer.android.com/topic/architecture/data-layer
		https://developer.android.com/topic/libraries/view-binding
		https://developer.android.com/topic/libraries/view-binding/migration
		https://developer.android.com/topic/libraries/data-binding#blog-posts
		https://developer.android.com/topic/libraries/data-binding/start
		https://developer.android.com/topic/libraries/data-binding/expressions

		ViewModel and LiveData
		https://developer.android.com/topic/libraries/architecture/viewmodel
		https://developer.android.com/topic/libraries/architecture/livedata
		https://developer.android.com/topic/libraries/architecture/saving-states

		Observer Pattern:
		https://en.wikipedia.org/wiki/Observer_pattern

		Kotlin Topics:
		https://kotlinlang.org/docs/scope-functions.html

	REFERENCE CODE: ANDROID APPLICATION MODERN ARCHITECHURE
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial17.zip And Unzip It!
			StudyMaterial17
				sunflower-main.zip

	Reference Material:
		Android Programming: The Big Nerd Ranch Guide, 4th Edition
		Refer It's Souce Code

_________________________________________________________________

DAY 18
_________________________________________________________________

	CODE REFERNCES: ANDROID MODERN ARCHITECHURE
		https://developer.android.com/courses/android-basics-kotlin/course
		https://developer.android.com/courses/pathways/android-architecture

	ASSSIGNMENT A2 : ANDROID APPLICATION MODERN ARCHITECTURE SAMPLES
		https://github.com/android/databinding-samples
		https://github.com/android/databinding-samples

		https://github.com/android/architecture-components-samples/tree/main/BasicSample
		https://github.com/android/architecture-components-samples

	ASSSIGNMENT A3 : ANDROID APPLICATION MODERN ARCHITECTURE CODING ASSIGNMENTS
		https://codelabs.developers.google.com/codelabs/android-databinding
		https://developer.android.com/codelabs/android-lifecycles#0
		https://developer.android.com/codelabs/advanced-kotlin-coroutines#0
		https://developer.android.com/codelabs/android-workmanager#0
		https://developer.android.com/codelabs/android-adv-workmanager#0
		https://developer.android.com/codelabs/advanced-android-kotlin-training-custom-views#0


__________________________________________________________________________

PROJECTS LIST
__________________________________________________________________________


	______________________________________

	Flight Booking Application
	______________________________________


	1. Admin Login
		Creation, Deletion, Updating, Listing and Filtering Of Flight Data
		List Flights, Flight Details

	2. User Login
		Listing and Filtering Of Flight Data
		List Flights, Flight Details

	3. Flights Booking and Order
		Flights Selection, Iternary and Travellers Details Input
		Without Payment Gateway Integration

	4. Rating The Services
	5. Preferred Flights
	______________________________________

	Bus Booking Application
	______________________________________


	1. Admin Login
		Creation, Deletion, Updating, Listing and Filtering Of Bus Data
		List Buses, Buses Details

	2. User Login
		Listing and Filtering Of Buses Data
		List Buses, Buses Details

	3. Buses Booking and Order
		Buses Selection, Iternary and Travellers Details Input
		Without Payment Gateway Integration

	4. Rating The Services
	5. Preferred Buses

	______________________________________

	Shows/Movies Booking Application
	______________________________________

	1. Admin Login
		Creation, Deletion, Updating, Listing and Filtering Of Shows/Movies Data
		List Shows/Movies, Shows/Movies Details

	2. User Login
		Listing and Filtering Of Shows/Movies Data
		List Shows/Movies, Shows/Movies Details

	3. Shows/Movies Booking and Order
		Shows/Movies Selection, Iternary and Viewers Details Input
		Without Payment Gateway Integration

	4. Rating The Services
	5. Preferred Shows/Movies

	______________________________________

	Insurance Policy Booking Application
	______________________________________

	1. Admin Login
		Creation, Deletion, Updating, Listing and Filtering Of Insurance Data
		List Insurances, Insurance Details

	2. User Login
		Listing and Filtering Of Insurances Data
		List Insurance, Insurances Details

	3. Insurances Purchasing and Order
		Insurances Selection, Iternary and Buyers Details Input
		Without Payment Gateway Integration

	4. Rating The Services
	5. Preferred Insurances Service Providers

	______________________________________

	Doctors Appointments Application
	______________________________________


	1. Admin Login
		Creation, Deletion, Updating, Listing and Filtering Of Doctors Data
		List Doctors, Doctor Details

	2. User Login
		Listing and Filtering Of Doctors Data
		List Doctor, Doctor Details

	3. Doctors Apoointment and Order
		Doctors Selection, Iternary and Patient Details Input
		Without Payment Gateway Integration

	4. Rating The Services
	5. Preferred Doctors


__________________________________________________________________________

CONTACT DETAILS
__________________________________________________________________________

	www.linkedin.com/in/amarjitlife
	amarjitlife@gmail.com
	+91 9980 777 145 

__________________________________________________________________________

FUTURE REFERENCES
__________________________________________________________________________

	Mythical Man-Month, The: Essays on Software Engineering, 
	Anniversary Edition Anniversary Edition, by Frederick Brooks Jr. 

	Structure And Interpretation Of Computer Program [ SICP BOOK ]
	Link : https://mitpress.mit.edu/sites/default/files/sicp/full-text/book/book.html

	Communicating Sequential Processes
	https://www.cs.cmu.edu/~crary/819-f09/Hoare78.pdf

	Continuation Concept
	https://jorgecastillo.dev/digging-into-kotlin-continuations

	Algorithms and Data Structure
	
		I. Data Structure Design
			Data Structures and Program Design in C++, by Robert L. Kruse

		II. Algorithms Design
			Introduction to the Design and Analysis of Algorithms 3rd Edition, Levitin
		
		III. Analysis Of Algorithms
			Introdution To Algorithms, Coreman 
	
		IV. Algorithms Design
			Algorithms Manual, Skiena


__________________________________________________________________________
__________________________________________________________________________
__________________________________________________________________________
__________________________________________________________________________
__________________________________________________________________________
