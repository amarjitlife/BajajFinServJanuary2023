/**** Run Following Commands
kotlinc KotlinClassesMore.kt -include-runtime -d classes.jar
java -jar classes.jar
****/

package learnKotlin

// DESIGN PRINCIPLE
//		Design Towards Immutability Rather Than Towards Mutability

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// In Kotlin
//		Classes Are Final By Default, So It Can't Be Inherited From
//		Members Are Also Final By Default

// In Java/C++
//		Classes Are Open By Default, So It Can Be Inherited From
//		Members Are Also Open By Default

open class Person(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
	// fun fullName() = "$firstName $lastName"
}

// Student Construtor
//		Takes Two Arguments Of String Type
//		Student Class Constructor Not Redefining/Defining firstName and lastName
//			i.e. Not Using val/var Before Name
//		Rather Reusing firstName and lastName Already Defined Person Class
data class Subject(val name: String, val grade: Char, val points: Double,
				   val credits: Double )

open class Student(firstName: String, lastName: String) : Person(firstName, lastName) {
	val passedSubjects : MutableList<Subject> = mutableListOf<Subject>()
	val failedSubjects : MutableList<Subject> = mutableListOf<Subject>()	

	fun recordGrade( subject: Subject ) {
		if ( subject.grade == 'F' ) failedSubjects.add( subject )
		else passedSubjects.add( subject )
	}

	open fun printGrades() {
		for ( subject in passedSubjects ) println("	$subject")
		for ( subject in failedSubjects ) println("	$subject")
	}

	fun isPassed() : Boolean {
		return failedSubjects.size <= 2
	}
}

fun playWithClassInheritance() {
	val personObject = Person("Gabbar", "Singh")
	println( personObject.firstName )
	println( personObject.lastName )
	// println( personObject.fullName() )
	println( personObject.fullName )

	val studentObject = Student("Samabha", "Aaaree O!")
	println( studentObject.firstName )
	println( studentObject.lastName )
	// println( studentObject.fullName() )
	println( studentObject.fullName )
}

fun playWithStudentGrades() {
	val alina = Student("Alina", "Mark")
						// Named Arguments
	val alinaEnglish = Subject(name = "English", grade = 'C', points = 7.0, 
																credits = 3.0 )
	// val alinaEnglish1 = Subject("English", grade = 'C', 7.0, credits = 3.0 )
	val alinaSc = Subject("Science", 'B', points = 8.0, credits = 4.0 )
	val alinaMaths = Subject("Mathematics", 'A', 9.0, 4.0)

	alina.recordGrade( alinaEnglish )
	alina.recordGrade( alinaSc )
	alina.recordGrade( alinaMaths )
	println( alina.fullName )
	alina.printGrades()
	println( "Passed : ${ alina.isPassed() }" )

	val gabbar = Student("Gabbar", "Singh")
	val gabbarDecoit = Subject(name = "Decoit", grade = 'A', points = 10.0, 
															credits = 3.0 )
	val gabbarKidnapping = Subject(name = "Kidnapping", grade = 'A', points = 10.0,
															credits = 4.0 )
	val gabbarShooting = Subject(name = "Shooting", grade = 'A', points = 10.0,
															credits = 4.0 )
	gabbar.recordGrade( gabbarDecoit )
	gabbar.recordGrade( gabbarKidnapping )
	gabbar.recordGrade( gabbarShooting )
	println( gabbar.fullName )
	gabbar.printGrades()

	println( "Passed : ${ gabbar.isPassed() }" )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

data class Game(val name: String, val grade: Char, val points: Double)

class StudentAthlete(firstName: String, lastName: String) : Student(firstName, lastName) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGame(game: Game) { gamesPlayed.add(game) }

	override fun printGrades() {
		super.printGrades()

		for ( game in gamesPlayed ) println("	$game")
	}
}

fun playWithStudentSportspersons() {
	val alina = StudentAthlete("Alina", "Mark")
						// Named Arguments
	val alinaEnglish = Subject(name = "English", grade = 'C', points = 7.0, 
																credits = 3.0 )
	val alinaSc = Subject("Science", 'B', points = 8.0, credits = 4.0 )
	val alinaMaths = Subject("Mathematics", 'A', 9.0, 4.0)
	val alinaTennis = Game(name = "Tennis", grade = 'A', points = 9.0 )

	alina.recordGrade( alinaEnglish )
	alina.recordGrade( alinaSc )
	alina.recordGrade( alinaMaths )
	alina.recordGame( alinaTennis )
	println( alina.fullName )
	alina.printGrades()
	println( "Passed : ${ alina.isPassed() }" )

	val gabbar = StudentAthlete("Gabbar", "Singh")
	val gabbarDecoit = Subject(name = "Decoit", grade = 'A', points = 10.0, credits = 3.0 )
	val gabbarKidnapping = Subject(name = "Kidnapping", grade = 'A', points = 10.0, credits = 4.0 )
	val gabbarShooting = Game(name = "Shooting", grade = 'A', points = 10.0)
	val gabbarHorseRiding = Game(name = "Horse Riding", grade = 'A', points = 10.0)

	gabbar.recordGrade( gabbarDecoit )
	gabbar.recordGrade( gabbarKidnapping )
	gabbar.recordGame( gabbarShooting )
	gabbar.recordGame( gabbarHorseRiding )

	println( gabbar.fullName )
	gabbar.printGrades()
	println( "Passed : ${ alina.isPassed() }" )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return 4 }
}

class FlutePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return 3 }
}

fun playWithRuntimeTypeCheck() {
	val guitarPlayer : GuitarPlayer = GuitarPlayer("Soumyadip", "Sengupta")
	println( guitarPlayer )

	println( guitarPlayer is GuitarPlayer )
	println( guitarPlayer is BandMember )
	println( guitarPlayer is Student )
	println( guitarPlayer is Person )

	val refererence1 = guitarPlayer
	val refererence2 : BandMember 	= guitarPlayer
	val refererence3 : Student 		= guitarPlayer
	val refererence4 : Person 		= guitarPlayer

	println( refererence1 is GuitarPlayer )
	println( refererence1 is BandMember )
	println( refererence1 is Student )
	println( refererence1 is Person )

	println( refererence2 is GuitarPlayer )
	println( refererence2 is BandMember )
	println( refererence2 is Student )
	println( refererence2 is Person )

	val sakira = BandMember("Sakira","Nagpal")
	println( sakira is GuitarPlayer )
	println( sakira is BandMember )
	println( sakira is Student )
	println( sakira is Person )	

	val milkha = StudentAthlete("Milkha", "Singh")
	//  error: incompatible types: GuitarPlayer and StudentAthlete
	// println( milkha is GuitarPlayer )
	// error: incompatible types: BandMember and StudentAthlete
	// println( milkha is BandMember )
	println( milkha is Student )
	println( milkha is Person )		
}

// EXPERIMENT ABOVE CODE! MOMENT DONE RAISE FLAG!!!

//_____________________________________________________

abstract class Mammal(val name: String, val birthDate: String) {
	abstract fun consumeFood()
}

class Human(name: String, birthDate: String) : Mammal(name, birthDate) {
	override fun consumeFood() {
		println("Human Consuming Food!!!....")
	}

	fun createBirthCertificate() = println("Birth Certificate Created!")
}

fun playWithMammals() {
	// error: cannot create an instance of an abstract class
	// val lion = Mammal("Lion", "10-10-10")

	val katrina = Human("Katrina Kaif", "10-10-10")
	katrina.consumeFood()
	katrina.createBirthCertificate()

	println( katrina is Human )
	println( katrina is Mammal )
}

// EXPERIMENT ABOVE CODE! MOMENT DONE RAISE FLAG!!!

//_____________________________________________________

interface Clickable3 {
    fun click()
    fun showOff() = println("I'm clickable!")
}

interface Focusable3 {
    fun setFocus(b: Boolean) =
        println("I ${if (b) "got" else "lost"} focus.")

    fun showOff() = println("I'm focusable!")
}

class Button3 : Clickable3, Focusable3 {
    override fun click() = println("I was clicked")

    override fun showOff() {
        super<Clickable3>.showOff()
        super<Focusable3>.showOff()
    }
}

fun playWithInterfacesAndRuntimeTypeCheck() {
	val button = Button3()

	println( button is Button3 )
	println( button is Clickable3 )
	println( button is Focusable3 )
}

// EXPERIMENT ABOVE CODE! MOMENT DONE RAISE FLAG!!!

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

sealed class Geometry {
	class Circle(val radius: Int) : Geometry()
	class Square(val side: Int) : Geometry()
	class Unknown(val size: Int) : Geometry()
}

// Following Both Functions Are Same.
fun sizeOfGeometry1( geometry : Geometry ) : Any {
	return when( geometry ) {
		is Geometry.Circle -> geometry.radius
		is Geometry.Square -> geometry.side
		else -> "Unknown Shape"
	}
}

fun sizeOfGeometry2( geometry : Geometry ) = when( geometry ) {
	is Geometry.Circle -> geometry.radius
	is Geometry.Square -> geometry.side
	else -> "Unknown Shape"
}

fun sizeOfGeometry3( geometry : Geometry ) : Int {
	return when( geometry ) {
		is Geometry.Circle -> geometry.radius
		is Geometry.Square -> geometry.side
		is Geometry.Unknown -> geometry.size
		// else -> -1
	}
}

fun playWithGeometries() {
	val circle1 = Geometry.Circle( 10 )
	val circle2 = Geometry.Circle( 20 )
	println( sizeOfGeometry1( circle1 ) )
	println( sizeOfGeometry1( circle2 ) )

	val square1 = Geometry.Square( 11 )
	val square2 = Geometry.Square( 22 )
	println( sizeOfGeometry1( square1 ) )
	println( sizeOfGeometry1( square2 ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Primary and Secondary Constructors

// Following Both Definitions Are Same
				  // Primary Constructor
class PersonAgain1(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
	// fun fullName() = "$firstName $lastName"
}

//				   constructor Keyword is Optional For Primary Constructor
class PersonAgain2 constructor(val firstName: String, val lastName: String) {
	val fullName = "$firstName $lastName"
	// fun fullName() = "$firstName $lastName"
}

fun playWithConstructors() {
	val person1 = PersonAgain1("Gabbar", "Singh")
	println( person1.fullName )

	val person2 = PersonAgain2("Gabbar", "Singh")
	println( person2.fullName )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Constructor Design Choice
//		Always Prefer Primary Constructor with Default Arguments
//			Over Constructor Overloading

class ShapeBetter(var boundaryColor: String, var fillColor: String = "Unknown") {
	fun printData() {
		println("Shape :: BoundryColor= $boundaryColor, FillColor = $fillColor")
	}	
}

open class Shape {
	var boundaryColor : String
	var fillColor : String

	// Secondary Constructors
	constructor( boundaryColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor = "Unknown"
	}

	// Overloading Constructor
	constructor( boundaryColor : String, fillColor : String ) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
	}

	open fun printData() {
		println("Shape :: BoundryColor= $boundaryColor, FillColor = $fillColor")
	}
}

fun playWithShape() {
	val shape1 = Shape("Black")
	shape1.printData()

	val shape2 = Shape("Black", "Green")
	shape2.printData()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Circle : Shape {
	var radius : Int

	// constructor( boundaryColor : String ) : super( boundaryColor ) {
	constructor( boundaryColor : String ) : this( boundaryColor, "Unknown", 0 ) {
	// constructor( boundaryColor : String ) {
		// error: explicit 'this' or 'super' call is required. There is no constructor in superclass that can be called without arguments

		// NOTE :: Following Is Redundent Code If Following Constructor Called
		//		this( boundaryColor, "Unknown", 10 )
		this.boundaryColor = boundaryColor
		this.fillColor = "Unknown"
		this.radius = 0
	}

	constructor( boundaryColor : String, fillColor: String, radius: Int ) : super(boundaryColor, fillColor) {
		this.boundaryColor = boundaryColor
		this.fillColor = fillColor
		this.radius = radius
	}

	override fun printData() {
		println("Circle :: BoundryColor= $boundaryColor, FillColor = $fillColor, Radius = $radius")
	}
}

fun playWithShapeAndCircle() {
	val circle1 = Circle("Black")
	circle1.printData()

	// val circle2 = Circle("Black", "Red")
	// circle2.printData()

	val circle3 = Circle("Black", "Green", 10)
	circle3.printData()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithLocalFunctionsAndClasses() { //Outside Function/Context
	// Local Function
	//		Function Defined Inside Function
	//		doSomething Is Local Function
	var something = 10
	fun doSomething() { //Inside Function/Context
		println("Local Function doSomething Called...")
		println("Accessing Inside : $something")
		something = 1111
	}

	// println("Accessing Outside : $something")
	// Local Classes
	//		Class Defined Inside Function
	//		Person Is Local Class To Function

	//Inside Class/Context
	class Person(val firstName: String, val lastName: String) { 
		val somethingAgain = something + 100

		fun doDance() = println("$firstName $lastName Doing Dance...")
		fun doSomething() {
			println("Accessing Inside Person: $somethingAgain")
			something = somethingAgain
		}
	}

	doSomething()
	println("Accessing Outside : $something")

	val person = Person("Gabbar", "Singh")
	println( person.firstName )
	println( person.lastName )
	person.doDance()
	person.doSomething()
	println("Accessing Outside : $something")
}

//_____________________________________________________

data class Privilege( val id: Int, val name: String )
// Property Visibility
//     Default Visibility Is Public i.e. Accessible Inside and Outside Of Defining Class
//     Private Visibility Accessible Only Inside Defining Class
//     Protected Visibility Accessible Inside Defining Class And Child Classes Of It
open class User(val firstName: String, val lastName: String, protected var age: Int, private var aadharCard: Int ) 

class PrivilegedUser(firstName: String, lastName: String, age: Int, aadharCard: Int) : User(firstName, lastName, age, aadharCard) {
    // Private To PrivilegeUser Class Only
    //      Cann't Be Accessed Outside Using Object Of PrivilegeUser Class
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add( privilege )
    }

    fun printPrivileges() {
        for ( privilege in privileges ) {
            println( "    $privilege" )
        }
    }

    fun details() : String {
        // error: cannot access 'aadharCard': 
        // it is invisible (private in a supertype) in 'PrivilegedUser'
        // return "$firstName $lastName $aadharCard"

        return "Name : $firstName $lastName, Age: $age"
    }
}

fun playWithPrivilegedUser() {
    val privilegedUser = PrivilegedUser(firstName = "Alice", lastName = "Carols", age = 21, aadharCard = 9999 )
    val invisiblePrivilege = Privilege( id = 11, name = "Can Become Invisible")
    val immortalPrivilege  = Privilege( id = 22, name = "Can Become Immortal")
    privilegedUser.addPrivilege( invisiblePrivilege )
    privilegedUser.addPrivilege( immortalPrivilege )
    println( privilegedUser.details() )
    privilegedUser.printPrivileges()
    // println( privilegedUser.privileges )
    // privilegedUser.privileges.add( Privilege( -99, "Something Useless Power"))
    // println( privilegedUser.privileges )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// In Kotlin
//		Class Defined Inside Class Are Nested Class By Default

// In Java
//		Class Defined Inside Class Are Inner Class By Default

class Car(val carName: String) { // Outside Class/Context
	val steering: Int = 0

	// Defining Nested Class Engine
	//		A Class Defined Inside Class
	//			Are Nested Class By Default In Kotlin
	//			Indide Class/Context CAN'T Access Outside Class/Context
	class Engine(val engineName: String) { // Inside Class/Context
		override fun toString() : String {
			// error: unresolved reference: carName
			// return "Car $carName Have Engine $engineName"
			return "Car Have Engine $engineName"
		}
	}
} 

class CarAgain(val carName: String) { // Outside Class/Context
	val steering: Int = 0

	// Defining Inner Class Engine
	//		A Class Defined Inside Class
	//			Indide Class/Context CAN Access Outside Class/Context
	inner class Engine(val engineName: String) { // Inside Class/Context
		override fun toString() : String {
			// error: unresolved reference: carName
			return "Car $carName Have Engine $engineName"
			// return "Car Have Engine $engineName"
		}
	}
} 

fun playWithNestedAndInnerClasses() {
	val harrier = Car("Avantador")
	val harrierEngine = Car.Engine("V12") 

	println( harrierEngine ) // harrierEngine.toString()

	val swift = CarAgain("Swift Dzire")
	val swiftEngine = swift.Engine("Fiat")

	println( swiftEngine ) // swiftEngine.toString()	
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// fun main( args: Array<String> ) {
fun main() {
	println("\nFunction : playWithClassInheritance")
	playWithClassInheritance()

	println("\nFunction : playWithStudentGrades")
	playWithStudentGrades()

	println("\nFunction : playWithStudentSportspersons")
	playWithStudentSportspersons()

	println("\nFunction : playWithRuntimeTypeCheck")
	playWithRuntimeTypeCheck()

	println("\nFunction : playWithMammals")
	playWithMammals()

	println("\nFunction : playWithInterfacesAndRuntimeTypeCheck")
	playWithInterfacesAndRuntimeTypeCheck()

	println("\nFunction : playWithGeometries")
	playWithGeometries()

	println("\nFunction : playWithConstructors")
	playWithConstructors()

	println("\nFunction : playWithShape")
	playWithShape()

	println("\nFunction : playWithShapeAndCircle")
	playWithShapeAndCircle()

	println("\nFunction : playWithLocalFunctionsAndClasses")
	playWithLocalFunctionsAndClasses()

	println("\nFunction : playWithPrivilegedUser")
	playWithPrivilegedUser()
	
	println("\nFunction : playWithNestedAndInnerClasses")
	playWithNestedAndInnerClasses()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}


