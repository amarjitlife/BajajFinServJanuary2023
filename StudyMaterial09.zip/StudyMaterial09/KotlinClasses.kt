/**** Run Following Commands
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar
****/

package learnKotlin

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

open class View {
	open fun click() = println("View Clicked!")
}
// Inheritance 
class Button : View() {
	override fun click() = println("Button Clicked")
	fun magic() = println("Button Magic..")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
	button.magic()

	var viewAgain: View = Button()
	viewAgain.click()
	// viewAgain.magic()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

open class View1 {
    open fun click() = println("View clicked")
}

class Button1: View1() {
    override fun click() = println("Button clicked")
}

fun View1.showOff() = println("I'm a view!")
fun Button1.showOff() = println("I'm a button!")

fun noOverridingForExtensionFunctions1() {
    val vo: View1 = Button1()
    vo.click()
    vo.showOff()

    val bo: Button1 = Button1()
    bo.click()
    bo.showOff()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Clickable2 {
    fun click()
}

class Button2 : Clickable2 {
    override fun click() = println("I was clicked")
}

fun functionButtonClick() {
    Button2().click()
}


//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Clickable3 {
    fun click()
    fun showOff() = println("I'm clickable!")
}

// Compiler Generate Following Interface and Class
//		To Work With < Java8
// interface Clickable3 {
//     fun click()
//     fun showOff()
// }

// class Clickable3Class implements Clickable3 {
//     fun click()
//     fun showOff() = println("I'm clickable!")
// }

interface Focusable3 {
    fun setFocus(b: Boolean) =
        println("I ${if (b) "got" else "lost"} focus.")

    fun showOff() = println("I'm focusable!")
}

class Button3 : Clickable3, Focusable3 {
    override fun click() = println("I was clicked")

    override fun showOff() {
        super<Clickable3>.showOff()
        super<Focusable3>.showOff()
    }
}

fun functionButtonClickableAndFocusable() {
    val button = Button3()
    button.showOff()
    button.setFocus(true)
    button.click()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

enum class Colour {
	RED, GREEN, BLUE, YELLOW, ORANGE, UKNOWN
}

fun mixColours(c1 : Colour, c2: Colour ) = when ( setOf(c1, c2) ) {
	setOf( Colour.BLUE, Colour.GREEN ) 	-> Colour.YELLOW
	setOf( Colour.RED, Colour.YELLOW )  -> Colour.ORANGE
	// else -> throw Exception("Dirty Colour!")
	// else -> "Unknown Colour"
	else -> Colour.UKNOWN
}

fun playWithColourMixing() {
	println( mixColours( Colour.GREEN, Colour.BLUE ) )
	println( mixColours( Colour.YELLOW, Colour.RED ) )
	// println( mixColours( Colour.GREEN, Colour.RED ) )	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// enum class Colour {
// 	RED, GREEN, BLUE, YELLOW, ORANGE, UKNOWN
// }

enum class Color(val r: Int, val g: Int, val b: Int) {
    RED(255, 0, 0), ORANGE(255, 165, 0),
    YELLOW(255, 255, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
    INDIGO(75, 0, 130), VIOLET(238, 130, 238);

    fun rgb() = (r * 256 + g) * 256 + b
}

fun declaringEnumClasses() {
    println(Color.BLUE.rgb())
    println(Color.BLUE.r)
    println(Color.BLUE.g)
    println(Color.BLUE.b)
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr 

fun evaluate(e: Expr) : Int = when(e) {
	is Num -> e.value
	is Sum -> evaluate(e.left) + evaluate(e.right)
	else -> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate(Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
    println( evaluate(Sum(Sum(Num(100), Num(200)), Num(99))))
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

sealed class Expr1 {
	class Num(val value: Int) : Expr1()
	class Sum(val left: Expr1 , val right: Expr1 ) : Expr1() 
}

fun evaluateAgain( e: Expr1 ) : Int = when(e) {
	is Expr1.Num -> e.value
	is Expr1.Sum -> evaluateAgain(e.left) + evaluateAgain(e.right)
	// else -> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluateAgain() {
	// 100 + 200
	println( evaluateAgain( Expr1.Sum( Expr1.Num(100), Expr1.Num(200) ) ) )

	// (100 + 200) + 99
    println( evaluateAgain( Expr1.Sum( Expr1.Sum( Expr1.Num(100), 
    	Expr1.Num(200)), Expr1.Num(99))))
}


// Sealed classes and interfaces represent restricted class hierarchies 
// that provide more control over inheritance. 

// All direct subclasses of a sealed class are known at compile time. 
// No other subclasses may appear outside a module within which 
// the sealed class is defined. 

// For example, third-party clients can't extend your sealed class 
// in their code. 

// Thus, each instance of a sealed class has a type from a limited set 
// that is known when this class is compiled.

// The same works for sealed interfaces and their implementations: 
// once a module with a sealed interface is compiled, 
// no new implementations can appear.

// In some sense, sealed classes are similar to enum classes:

// the set of values for an enum type is also restricted, 
// but each enum constant exists only as a single instance, 
// whereas a subclass of a sealed class can have multiple instances, 
// each with its own state.
/*
sealed interface Error

sealed class IOError(): Error

class FileReadError(val file: File): IOError()
class DatabaseError(val source: DataSource): IOError()

object RuntimeError : Error

fun log(e: Error) = when(e) {
    is FileReadError -> { println("Error while reading file ${e.file}") }
    is DatabaseError -> { println("Error while reading from database ${e.source}") }
    is RuntimeError ->  { println("Runtime error") }
    // the `else` clause is not required because all the cases are covered
}
*/

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

//								Constructor With Default Argument
class User( val nickName: String, val isSubscribed: Boolean = true )

fun playWithUser() {
	val alice = User("Alice")
	println( alice.nickName )
	println( alice.isSubscribed )

	val gabbar = User("Gabbar Singh", false)
	println( gabbar.nickName )
	println( gabbar.isSubscribed )	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun getFacebookName( accountID: Int ) = "FB:$accountID"

// Interface With Property
interface User1 {
	val nickname : String
}

class PrivateUser( override val nickname: String ) : User1

class SubscribingUser( val email: String ) : User1 {
	override val nickname : String
		get() = email.substringBefore('@')
}

class FacebookUser(val accountID: Int) : User1 {
	override val nickname = getFacebookName( accountID )
}

fun playWithInterfaceProperties() {
	var gabbar = PrivateUser("gabbar@ramgarh.com")
	println( gabbar.nickname )

	var basanti = SubscribingUser("basanti@ramgarh.com")
	println( basanti.nickname )

	var thakur = FacebookUser(999)
	println( thakur.nickname )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface User2 {
	// error: class 'Employee' is not abstract and does not implement 
	// abstract member public abstract val email: String 
	// defined in learnKotlin.User2
	val email : String
	val nickname : String
		get() = email.substringBefore('@')

	var name: String
		get() = "Unknown!"
		set( value ) {
			// error: property in an interface cannot have a backing field
			//											     Member Variable
			// field = value
			println("Setter Getting Called : $value")
		}
}

class Employee() : User2 {
	override val email: String = "gabbar@ramgarh.com"
		// get() = "gabbar@ramgarh.com"
}

fun playWithEmployee() {
	val gabbar = Employee()
	println(gabbar.email)
	println(gabbar.name)
	println(gabbar.nickname)	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class User3( val name : String ) {
	var address: String = "Unspecified"
		get() {
			println("Getter Called...")			
			println("Address Field Value : $field")
			return field		
		}

		set( value : String ) {
			println("Setter Called...")
			println("Address Value Before Setting : $field")
			field = value
			println("Address Value After  Setting : $field")
		}
}

fun playWithUser3() {
	val gabbar = User3("Gabbar Singh")
	println( gabbar.name )
	println( gabbar.address )

	gabbar.address = "Ramragh, Karnatka"
	println( gabbar.address )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class User4 {
	val name : String = "Unknown!"
	var address: String = "Unspecified"
		// get() {
		// 	return field
		// }		
		get() {
			println("Getter Called...")			
			println("Address Field Value : $field")
			return field		
		}

		set( value : String ) {
			println("Setter Called...")
			println("Address Value Before Setting : $field")
			field = value
			println("Address Value After  Setting : $field")
		}
}

fun playWithUser4() {
	val gabbar = User4()
	println( gabbar.name )
	println( gabbar.address )

	gabbar.address = "Ramragh, Karnatka"
	println( gabbar.address )

	// val basanti = User4("Basanti", "Ramgarh")
	// println( basanti.name )
	// println( basanti.address )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class LengthCounter {
	var counter : Int = 0
		private set

	fun addWord( word: String ) {
		counter = counter + word.length
	}
}

fun playWithLengthCounter() {
	val lengthCounter = LengthCounter()
	lengthCounter.addWord("Hi!")
	println( lengthCounter.counter )

	lengthCounter.addWord("Good")
	println( lengthCounter.counter )

	// error: cannot assign to 'counter': the setter is private in 'LengthCounter'
	// lengthCounter.counter = 1000
	// println( lengthCounter.counter )	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Client1(val name: String, val postalCode: Int) {
	// error: 'toString' hides member of supertype 'Any' and needs 'override' modifier
	override fun toString() : String {
		return "Client1(name=$name, postalCode=$postalCode)"
	}
}

fun playWithClient1Printing() {
	val veeru = Client1( "Veeru", 111111 )
	println( "Name: ${veeru.name}" )
	println( "Code: ${veeru.postalCode}" )

	println( veeru ) // veeru.toString()
	// Client1(name=Veeru, postalCode=111111)
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Client2(val name: String, val postalCode: Int) {
	override fun toString() = "Client2(name=$name, postalCode=$postalCode)"

	override fun equals( other : Any? ) : Boolean {
		if ( other == null || other !is Client2 )
			return false
		return name == other.name && postalCode == other.postalCode
	}
}

fun playWithClient2() {
	val veeru1 = Client2( "Veeru", 111111 )
	println( veeru1 ) // veeru.toString()
	// Client1(name=Veeru, postalCode=111111)

	val veeru2 = Client2( "Veeru", 111111 )
	println( veeru2 ) // veeru.toString()

	val jay = Client2( "Jay", 777777 )
	println( jay ) // jay.toString()

	println( veeru1 == veeru2 ) // veeru1.equals( veeru2 )
	println( veeru1 == jay )    // veeru1.equals( jay )
}

//_____________________________________________________

// Data Classes
//		Compiler Will Generate Following Methds
//		1. toString() Method
//		2. equals Method
//				Will Compare All The Properties
//		2. hashCode Method
//				Will Generate HashCode Based On
// 				All The Properties
data class Client3(val name: String, val postalCode: Int)

fun playWithClient3() {
	val veeru1 = Client3( "Veeru", 111111 )
	println( veeru1 ) // veeru.toString()
	// Client1(name=Veeru, postalCode=111111)

	val veeru2 = Client3( "Veeru", 111111 )
	println( veeru2 ) // veeru.toString()

	val jay = Client3( "Jay", 777777 )
	println( jay ) // jay.toString()

	println( veeru1 == veeru2 ) 
	println( veeru1 == jay )    
}


//_____________________________________________________

data class Client4(val name: String, val postalCode: Int) {
	override fun toString() = "Client2(name=$name, postalCode=$postalCode) <<<"
}

fun playWithClient4() {
	val veeru1 = Client4( "Veeru", 111111 )
	println( veeru1 ) // veeru.toString()
	// Client1(name=Veeru, postalCode=111111)

	val veeru2 = Client4( "Veeru", 111111 )
	println( veeru2 ) // veeru.toString()

	val jay = Client4( "Jay", 777777 )
	println( jay ) // jay.toString()

	println( veeru1 == veeru2 ) 
	println( veeru1 == jay )    
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// class India {

// object Classes
//		Singleton Classes In Kotlin
object India {
	// Instance Member
	fun name() : String {
		return "Hindustan!"
	}
}

fun playWithIndia() {
	// Instance Name Is As Type Name
	//		India Is Singleton Instance India
	val data = India.name()
	println( data )
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// fun main( args: Array<String> ) {
fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : noOverridingForExtensionFunctions1")
	noOverridingForExtensionFunctions1()

	println("\nFunction : functionButtonClick")
	functionButtonClick()

	println("\nFunction : functionButtonClickableAndFocusable")
	functionButtonClickableAndFocusable()

	println("\nFunction : playWithColourMixing")
	playWithColourMixing()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithUser")
	playWithUser()

	println("\nFunction : playWithInterfaceProperties")
	playWithInterfaceProperties()

	println("\nFunction : playWithEmployee")
	playWithEmployee()

	println("\nFunction : playWithUser3")
	playWithUser3()

	println("\nFunction : playWithUser4")
	playWithUser4()

	println("\nFunction : playWithLengthCounter")
	playWithLengthCounter()

	println("\nFunction : playWithClient1Printing")
	playWithClient1Printing()

	println("\nFunction : playWithClient2")
	playWithClient2()

	println("\nFunction : playWithClient3")
	playWithClient3()

	println("\nFunction : playWithClient4")
	playWithClient4()

	println("\nFunction : playWithIndia")
	playWithIndia()

	println("\nFunction : playWithIndia")
	playWithIndia()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

// https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)
// https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)
// https://www.digitalocean.com/community/tutorials/java-singleton-design-pattern-best-practices-examples
// https://www.digitalocean.com/community/tutorials/java-singleton-design-pattern-best-practices-examples
