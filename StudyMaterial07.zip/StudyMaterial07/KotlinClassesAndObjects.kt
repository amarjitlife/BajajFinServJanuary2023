/**** Run Following Commands
kotlinc KotlinClassesAndObjects.kt -include-runtime -d classesAndObjects.jar
java -jar classesAndObjects.jar
****/

package learnKotlin

//_____________________________________________________

open class View {
	open fun click() = println("View Clicked!")
}
// Inheritance 
class Button : View() {
	override fun click() = println("Button Clicked")
	fun magic() = println("Button Magic..")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
	button.magic()

	var viewAgain: View = Button()
	viewAgain.click()
	// viewAgain.magic()
}

//_____________________________________________________

open class View1 {
    open fun click() = println("View clicked")
}

class Button1: View1() {
    override fun click() = println("Button clicked")
}

fun View1.showOff() = println("I'm a view!")
fun Button1.showOff() = println("I'm a button!")

fun noOverridingForExtensionFunctions1() {
    val vo: View1 = Button1()
    vo.click()
    vo.showOff()

    val bo: Button1 = Button1()
    bo.click()
    bo.showOff()
    // bo.magic()
}

//_____________________________________________________

interface Clickable {
    fun click()
}

class Button : Clickable {
    override fun click() = println("I was clicked")
}

fun functionButtonClick() {
    Button().click()
}



//_____________________________________________________


interface Clickable {
    fun click()
    fun showOff() = println("I'm clickable!")
}

interface Focusable {
    fun setFocus(b: Boolean) =
        println("I ${if (b) "got" else "lost"} focus.")

    fun showOff() = println("I'm focusable!")
}

class Button : Clickable, Focusable {
    override fun click() = println("I was clicked")

    override fun showOff() {
        super<Clickable>.showOff()
        super<Focusable>.showOff()
    }
}

fun functionButtonClickableAndFocusable() {
    val button = Button()
    button.showOff()
    button.setFocus(true)
    button.click()
}


//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// fun main( args: Array<String> ) {
fun main() {
	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : noOverridingForExtensionFunctions1")
	noOverridingForExtensionFunctions1()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
