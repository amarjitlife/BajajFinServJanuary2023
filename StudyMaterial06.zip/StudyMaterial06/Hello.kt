/****  Compling and Running Kotlin Code
cd Desktop/LearnKotlin/

Run Following Commands
kotlinc hello.kt -include-runtime -d hello.jar
java -jar hello.jar
****/

fun main() {
	println("Hello World!!!")
}

// Compiler Will Generate Following Java Code
//	For Above Kotlin Code
// class HelloKt {
// 	public static void main() {
// 		System.out.println("Hello World!!!");
// 	} 
// }
