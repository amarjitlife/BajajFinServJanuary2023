/*
javac JavaInterfaces.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaInterfaces
*/
package learnJava;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Objects;

import java.util.Comparator;
import static java.util.Comparator.*;

import java.util.function.BiFunction;
import java.util.function.IntConsumer;
import java.util.Random;


//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// What It Will Do!
interface IntSequence {
	boolean hasNext();
	int next();
}

// How, When, Where, Which Way To Do!
// error: DigitalSequence is not abstract and 
// does't override abstract method next() in IntSequence
class DigitalSequence implements IntSequence {
	public boolean hasNext() {
		System.out.println("DigitalSequence: Has Next...");
		return true;
	}

	public int next() {        
		System.out.println("DigitalSequence: Next...");
		return 1;
	}
}

class SquareSequence implements IntSequence {
	public boolean hasNext() {
		System.out.println("SquareSequence: Has Next...");
		return true;
	}

	public int next() {        
		System.out.println("SquareSequence: Next...");
		return 1;
	}
}

class IntSequenceDemo {
	// public static void consumeSequence( DigitalSequence digits ) {
	//     digits.hasNext();
	//     digits.next();
	// }

	// public static void consumeSequence( SquareSequence digits ) {
	//     digits.hasNext();
	//     digits.next();
	// }

	// Polymorphic Function
	//      Mechanism : Using Interface
	public static void consumeSequence( IntSequence digits ) {
		digits.hasNext();
		digits.next();
	}

	public static void playWithSequence() {
		DigitalSequence digits = new DigitalSequence();
		consumeSequence( digits );
	
		SquareSequence squares = new SquareSequence();
		consumeSequence( squares );
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface IntSequence1 {
	boolean hasNext();
	int next();
}

class DigitSequence1 implements IntSequence1 {
	private int number;

	public DigitSequence1(int n) {
		number = n;
	}

	public boolean hasNext() {
		return number != 0;
	}

	public int next() {
		int result = number % 10;
		number /= 10;
		return result;
	}
	
	public int rest() {
		return number;
	}
}

class SquareSequence1 implements IntSequence1 {
	private int i;

	public boolean hasNext() {
		return true;
	}

	public int next() {
		i++;
		return i * i;
	}
}

class IntSequenceDemo1 {
	public static double average(IntSequence1 seq, int n) {
		int count = 0;
		double sum = 0;
		while (seq.hasNext() && count < n) {
			count++;
			sum += seq.next();
		}
		return count == 0 ? 0 : sum / count;
	}

	public static void playWithInterfaces() {
		SquareSequence1 squares = new SquareSequence1();
		double avg = average(squares, 100);
		System.out.println("Average of first 100 squares: " + avg);
		
		IntSequence1 digits = new DigitSequence1(1729);
		while (digits.hasNext()) System.out.print(digits.next() + " ");
		System.out.println();
		
		digits = new DigitSequence1(1729);
		avg = average(digits, 100);
			// Will only look at the first four sequence values
		System.out.println("Average of the digits: " + avg);
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Identified {
	default int getId() { return Math.abs( hashCode()); }
}

interface Person1 {
	String getName();
	default int getId() { return 0; }
}

class Employee implements Person1, Identified {
	private int id = 111;
	private String name;
	private double salary;

	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	public void raiseSalary(double byPercent) {
		double raise = salary * byPercent / 100;
		salary = salary + raise;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return Identified.super.getId() + Person1.super.getId();
		// return id; 
	}
}

class EmployeeDemo {
	public static void playWithEmployee() {
		Employee gabbar = new Employee("Gabbar Singh", 50000);
		gabbar.raiseSalary( 100.0 );

		System.out.println( gabbar.getName() );
		System.out.println( gabbar.getId() );
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Employee1 implements Comparable<Employee1> {
    private String name;
    private double salary;
        
    public Employee1(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    
    public Employee1(double salary) {
        this.name = "";
        this.salary = salary;
    }        
    
    public Employee1(String name) {
        // salary automatically set to zero
        this.name = name;
    } 
    
    public Employee1() {
        this("", 0);
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int compareTo(Employee1 other) {
        return Double.compare(salary, other.salary);
    }
}

class EmployeeDemo1 {
	public static void playWithEmployee() {
		Employee1 gabbar = new Employee1("Gabbar Singh", 50000);
		gabbar.raiseSalary( 100.0 );
		System.out.println( gabbar.getName() );
		System.out.println( gabbar.getSalary() );

		Employee1 thakur = new Employee1("Thakur", 500000);
		System.out.println( thakur.getName() );
		System.out.println( thakur.getSalary() );

		System.out.println( gabbar.compareTo( thakur ) );
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.Arrays;
// import java.util.Comparator;

class LengthComparator implements Comparator<String> {
    public int compare(String first, String second) {
        return first.length() - second.length();
    }
}

class SortDemo {
    public static void playWithComparator() {
        String[] friends = { "Peter", "Paul", "Mary" };
        Arrays.sort(friends); // friends is now ["Mary", "Paul", "Peter"]
        System.out.println(Arrays.toString(friends));
        
        friends = new String[] { "Peter", "Paul", "Mary" };
        Arrays.sort(friends, new LengthComparator());
        System.out.println(Arrays.toString(friends));
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// interface Operator {
// 	int operator(int x, int y);
// }

// interface Operation {
// 	int operation(int x, int y, Operator operator);
// }

// class Mathematics {
// 	public static int sum(int x, int y) { return x + y; }
// 	public static int sub(int x, int y) { return x + y; }

// 	public static int calculator(int x, int y, )
// }


// Java program to demonstrate lambda expressions to
// implement a user defined functional interface.

// SAM Interfaces
// 		Single Abstract Method Interfaces
// @FunctionalInterface
interface Operation {
	int calculate(int value);
}

class Square implements Operation {
	public int calculate(int value) {
		return value * value;
	}
}

class SquareDemo {
	public static void playWithSqaure() {
		int a = 5, result = 0;

		Square square = new Square();
		result = square.calculate( a );
		System.out.println( result );

		// Lambda Expression 
		//		To define the calculate method
		Operation operation = (int value) -> value * value;
		// Compiler Will Generate Following Code For Above Line
		// class TemporaryClass implements Operation {
		// 		public int calculate(int value) {
		// 			return value * value;
		// 		}
		// }
		// Operation operation = new TemporaryClass();

		// parameter passed and return type must be
		// same as defined in the prototype
		result = operation.calculate( a );
		System.out.println(result);
	}
}

//_____________________________________________________

// SAM Interface
interface BiOperation {
	int operate( int x, int y );
}

class Sum implements BiOperation {
	public int operate( int x, int y ) { return x + y; }
}

class Sub implements BiOperation {
	public int operate( int x, int y ) { return x - y; }
}

class Calculator {
	public static int sum( int x, int y ) { return x + y; }
	public static int sub( int x, int y ) { return x - y; }

	// public int sum( int x, int y ) { return x + y; }
	// public int sub( int x, int y ) { return x - y; }

	// Polymorpic Function
	//		Mechanism: Passing A Behaviour To Behaviour
	public static int calculate(int x, int y, BiOperation operation) {
		return operation.operate(x, y);
	}
}

class CalculatorDemo {
	public static void playWithCalculator() {
		int a = 40, b = 20, result = 0;
											// Passing Object				
		result = Calculator.calculate( a, b, new Sum() );
		System.out.println(result);
											// Passing Function Reference
		result = Calculator.calculate(a, b, new Sub() );
		System.out.println(result);
											// Passing Function Reference				
		result = Calculator.calculate( a, b, Calculator::sum );
		System.out.println(result);
											// Passing Function Reference
		result = Calculator.calculate(a, b, Calculator::sub );
		System.out.println(result);

		// Lambda Expression 
		//		Passing definition for the operate method
											// Passing Lambda Expression
		result = Calculator.calculate( a, b, (int x, int y) -> x + y );
		System.out.println(result);
											// Passing Lambda Expression
		result = Calculator.calculate(a, b, (int x, int y) -> x - y );
		System.out.println(result);
		// BiOperation operation = (int x, int y) -> x + y;
		// Compiler Will Generate Following Code For Above Line
		// class TemporaryClass implements BiOperation {
		// 		public int operate(int x, int y) {
		// 			return x + y;
		// 		}
		// }
		// BiOperation operation = new TemporaryClass();
		// result = Calculator.calculate(a, b, operation );

		// BiFunction sumLambda = (int x, int y) -> x + y;
		// result = Calculator.calculate( a, b,  sumLambda);
		// System.out.println(result);
	}
}

//_____________________________________________________

// import java.util.function.BiFunction;

class MethodReferencesExamples {    
    public static <T> T mergeThings(T a, T b, BiFunction<T, T, T> merger) {
        return merger.apply(a, b);
    }
    
    public static String appendStrings(String a, String b) {
        return a + b;
    }
    
    public String appendStrings2(String a, String b) {
        return a + b;
    }

    public static void playWithMethodReferences() {
        MethodReferencesExamples myApp = new MethodReferencesExamples();

        // Calling the method mergeThings with a lambda expression
        System.out.println(MethodReferencesExamples.
            mergeThings("Hello ", "World!", (a, b) -> a + b));
        
        // Reference to a static method
        System.out.println(MethodReferencesExamples.
            mergeThings("Hello ", "World!", MethodReferencesExamples::appendStrings));

        // Reference to an instance method of a particular object        
        System.out.println(MethodReferencesExamples.
            mergeThings("Hello ", "World!", myApp::appendStrings2));
        
        // Reference to an instance method of an arbitrary object of a
        // particular type
        System.out.println(MethodReferencesExamples.
            mergeThings("Hello ", "World!", String::concat));
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.ArrayList;
// import java.util.Arrays;

class LambdaDemo {
    public static void playWithLamdbas() {
        String[] friends = { "Peter", "Paul", "Mary" };
        Arrays.sort(friends,
                (first, second) -> first.length() - second.length());
        System.out.println(Arrays.toString(friends));
       
        ArrayList<String> enemies = new ArrayList<>(
        	Arrays.asList("Malfoy", "Crabbe", "Goyle", null));
        enemies.removeIf(element -> element == null);
        System.out.println(enemies);        
    }
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Objects;

class MethodReferenceDemo {
    public static void playWithMethodReferences() {
        String[] strings = { "Mary", "had", "a", "little", "lamb" };
        Arrays.sort(strings, String::compareToIgnoreCase);
        System.out.println(Arrays.toString(strings));
        ArrayList<String> list = new ArrayList<>(
        	Arrays.asList("Malfoy", "Crabbe", "Goyle", null));
        list.removeIf(Objects::isNull);
        list.forEach(System.out::println);
    }
}

//_____________________________________________________

// import java.util.function.IntConsumer;

class FunctionalInterfaceDemo {
    public static void repeat(int n, Runnable action) {
        for (int i = 0; i < n; i++)
            action.run();
    }

    public static void repeat(int n, IntConsumer action) {
        for (int i = 0; i < n; i++)
            action.accept(i);
    }

    public static void repeatMessage(String text, int count) {
        Runnable r = () -> {
           for (int i = 0; i < count; i++) {
              System.out.println(text);
           }
        };
        new Thread(r).start();                  
     }
    
    public static void playWithFunctionalInterfaces() {
        repeat(10, () -> System.out.println("Hello, World!"));
        repeat(10, i -> System.out.println("Countdown: " + (9 - i)));
        repeatMessage("Hello", 10);
    }
}

//_____________________________________________________

// import java.util.Arrays;
// import java.util.Comparator;
// import static java.util.Comparator.*;

class Person {
    private String first;
    private String middle;
    private String last;

    public Person(String first, String middle, String last) {
        this.first = first;
        this.middle = middle;
        this.last = last;
    }

    public Person(String first, String last) {
        this.first = first;
        this.last = last;
    }
    
    public String getFirstName() {
        return first;
    }
    
    public String getMiddleName() {
        return middle;
    }
    
    public String getLastName() {
        return last;
    }
    
    public String getName() {
        if (middle == null) {
            return first + " " + last;
        }
        else {
            return first + " " + middle + " " + last;
        }
    }
    
    public String toString() {
        return getName();
    }
}

class ComparatorDemo {
    public static void playWithComparator() {
        Person[] people = {
                new Person("George", "Washington"),
                new Person("John", "Adams"),
                new Person("Thomas", "Jefferson"),
                new Person("James", "Madison"),
                new Person("James", "Monroe"),
                new Person("John", "Quincy", "Adams"),
                new Person("Andrew", "Jackson"),
                new Person("Martin", "van Buren"),
                new Person("William", "Henry", "Harrison"),
                new Person("John", "Tyler"),
                new Person("James", "Knox", "Polk"),
                new Person("Zachary", "Taylor"),
                new Person("Millard", "Fillmore"),
                new Person("Franklin", "Pierce"),
                new Person("James", "Buchanan"),
                new Person("Abraham", "Lincoln"),
                new Person("Andrew", "Johnson"),
                new Person("Ulysses", "S.", "Grant"),
                new Person("Rutherford", "Birchard", "Hayes"),
                new Person("James", "Abram", "Garfield"),
        };
                
        Arrays.sort(people, Comparator.comparing(Person::getName));
        System.out.println(Arrays.toString(people));
        
        Arrays.sort(people,
                Comparator.comparing(Person::getLastName)
                .thenComparing(Person::getFirstName));
        System.out.println(Arrays.toString(people));
        
        Arrays.sort(people, Comparator.comparing(Person::getName,
                (s, t) -> s.length() - t.length()));
        
        Arrays.sort(people, Comparator.comparingInt(p -> p.getName().length()));
        System.out.println(Arrays.toString(people));
        
        Arrays.sort(people, comparing(Person::getMiddleName,
                nullsFirst(naturalOrder())));
        System.out.println(Arrays.toString(people));

        Arrays.sort(people, comparing(Person::getName,
                reverseOrder()));
        System.out.println(Arrays.toString(people));
    }
}

//_____________________________________________________

// import java.util.Random;

class LocalClassDemo {
    private static Random generator = new Random();

    public static IntSequence randomInts(int low, int high) {
    	// Local Class
    	//		Class Defined Inside Function
        class RandomSequence implements IntSequence {
            public int next() { 
            	return low + generator.nextInt(high - low + 1); 
            }
            public boolean hasNext() { return true; }
        }

        return new RandomSequence();
    }

    public static void playWithLocalClasses() {
        IntSequence dieTosses = randomInts(1, 6);
        for (int i = 0; i < 10; i++) System.out.println(dieTosses.next());
    }
}


//_____________________________________________________

// import java.util.Random;

class AnonymousClassDemo {
    private static Random generator = new Random();

    public static IntSequence randomInts(int low, int high) {
        return new IntSequence() {
            public int next() { return low + generator.nextInt(high - low + 1); }
            public boolean hasNext() { return true; }
        };
    	
    	// Compiler Will Generate Following Code
    	// class TempClass implements IntSequence {
        //    	public int next() { return low + generator.nextInt(high - low + 1); }
        //     public boolean hasNext() { return true; }    		
    	// }
    	// return new TempClass();
    }


    public static void playWithAnonymousClass() {
        IntSequence dieTosses = randomInts(1, 6);
        for (int i = 0; i < 10; i++) System.out.println(dieTosses.next());
    }
}


//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaInterfaces {
	public static void main( String[] args ) {
		System.out.println("\nFunction : IntSequenceDemo.playWithSeqeunce");
		IntSequenceDemo.playWithSequence();

		System.out.println("\nFunction : IntSequenceDemo1.playWithInterfaces");
		IntSequenceDemo1.playWithInterfaces();

		System.out.println("\nFunction : EmployeeDemo.playWithEmployee");
		EmployeeDemo.playWithEmployee();

		System.out.println("\nFunction : EmployeeDemo1.playWithEmployee");
		EmployeeDemo1.playWithEmployee();

		System.out.println("\nFunction : SortDemo.playWithComparator");
		SortDemo.playWithComparator();

		System.out.println("\nFunction : SquareDemo.playWithSqaure");
		SquareDemo.playWithSqaure();
		
		System.out.println("\nFunction : CalculatorDemo.playWithCalculator");
		CalculatorDemo.playWithCalculator();

		System.out.println("\nFunction : MethodReferencesExamples.playWithMethodReferences");
		MethodReferencesExamples.playWithMethodReferences();

		System.out.println("\nFunction : LambdaDemo.playWithLamdbas");
		LambdaDemo.playWithLamdbas();

		System.out.println("\nFunction : MethodReferenceDemo.playWithMethodReferences");
		MethodReferenceDemo.playWithMethodReferences();

		System.out.println("\nFunction : FunctionalInterfaceDemo.playWithFunctionalInterfaces");
		FunctionalInterfaceDemo.playWithFunctionalInterfaces();

		System.out.println("\nFunction : ComparatorDemo.playWithComparator");
		ComparatorDemo.playWithComparator();

		System.out.println("\nFunction : LocalClassDemo.playWithLocalClasses");
		LocalClassDemo.playWithLocalClasses();

		System.out.println("\nFunction : AnonymousClassDemo.playWithAnonymousClass");
		AnonymousClassDemo.playWithAnonymousClass();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
