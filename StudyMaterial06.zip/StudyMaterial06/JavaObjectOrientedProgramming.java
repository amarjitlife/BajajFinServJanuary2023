/*
javac JavaObjectOrientedProgramming.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaObjectOrientedProgramming
*/
package learnJava;

import java.util.Random;
import java.util.Scanner;
import java.time.LocalDate;
import java.util.ArrayList;
import static java.lang.Math.*;
import java.util.ArrayList;

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Employee {
	private String name;
	private double salary;
		
	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	public void raiseSalary(double byPercent) {
		double raise = salary * byPercent / 100;
		salary += raise;    
	}
	
	public String getName() {
		return name;
	}
	
	public double getSalary() {
		return salary;
	}
}


class EvilManager {
	private String name;
	private Random generator;

	public EvilManager(String name) {
		this.name = name;
		generator = new Random();
	}
	
	public void giveRandomRaise(Employee e) {
		double percentage = 10 * generator.nextDouble();
		e.raiseSalary(percentage);
	}
	
	public void increaseRandomly(double x) {
		double amount = x * 10 * generator.nextDouble();
		x += amount;
	}
	
	public void replaceWithZombie(Employee e) {
		e = new Employee("", 0);
	}

	public String getName() {
		return name;
	}
}

class EmployeeDemo {
	public static void playWithEmployee() {
		Employee viru = new Employee("Viru", 50000);

		viru.raiseSalary(10);
		
		System.out.println(viru.getName());
		System.out.println(viru.getSalary());

		EvilManager gabbar = new EvilManager("Gabbar Singh");
		gabbar.giveRandomRaise(viru);
		gabbar.increaseRandomly(900.0);
		System.out.println(gabbar.getName());
		System.out.println(viru.getSalary());
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class StaticMethods {
	public void sayHello() {
		System.out.println("Hello World!!! Instance Member");
	}

	public static double average(double x, double y) {
		double sum = x + y;
		return sum / 2;
	}
	
	public static void calculateAverage() {
		System.out.print("\nEnter two numbers: ");
		Scanner in = new Scanner(System.in);
		double a = in.nextDouble();
		double b = in.nextDouble();
		double result = average(a, b);
		System.out.println("Average: " + result);
	}
}

class StaticMethodDemo {
	public static void playWithClassMembers() {
		double average = StaticMethods.average(10, 20);
		System.out.printf("\nAverage : %f", average);

		StaticMethods.calculateAverage();
		// Compilation Error
		//	error: non-static method sayHello() cannot be referenced from 
		//	a static context
		// StaticMethods.sayHello();

		StaticMethods instance = new StaticMethods();
		instance.sayHello();

		// BAD CODING PRACTICES
		//		Type Member Must Be Accessed Using Types Only
		instance.average(100, 200);
		instance.calculateAverage();


	}
}

//_____________________________________________________

class Employee1 {
	private String name = "Gabbar Singh"; // Default Values Initialisation
	private double salary;
	private final int id;
		
	{ // An initialization block

		Random generator = new Random(); 
		id = 1 + generator.nextInt(1_000_000);
		System.out.println("Before Name Initialisation Block: " + name );
		name = "Viru";
		System.out.println("After Name Initialisation Block: " + name );
	}

	// Compiler Will Generate Following
	// public Employee Employee(String name, double salary) {    
	public Employee1(String name, double salary) {
		System.out.println("Constructor Name: " + name );

		System.out.println("Constructor Salary: " + salary );
		this.name = name;
		this.salary = salary;

		// return Employee(name, salary); Recursive Call
		// Compiler Will Generate Following
		// return this;
		System.out.println("Constructor Name: " + name );
	}
	
	public Employee1(double salary) {
		// name already set to ""
		this.salary = salary;
	}        
	
	public Employee1(String name) {
		// salary automatically set to zero
		this.name = name;
	} 
	
	public Employee1() {
		// error: call to this must be first statement in constructor
		// System.out.println("Constructor Name: " + name );
		// Constructor Call
		//		Mapped To Employee(String name, double salary)        
		this("Ding Dong", 0);
		// this.name = "Thakur";
		System.out.println("Constructor Name: " + name );
	}

	public void raiseSalary(double byPercent) {
		double raise = salary * byPercent / 100;
		salary += raise;    
	}
	
	public String getName() {
		return name;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public int getId() {
		return id;
	}
}

class EmployeeDemo1 {
	public static void playWithEmployee() {
		Employee1 james = new Employee1("Jay", 500000);
			// calls Employee(String, double) constructor
		Employee1 anonymous = new Employee1("", 40000);
			// calls Employee(double) constructor
		Employee1 unpaid = new Employee1("Igor Intern");
		Employee1 e = new Employee1();
			// no-arg constructor
	}
}

//_____________________________________________________

// import java.time.LocalDate;
// import java.util.ArrayList;

class CreditCardForm {
	// Initialisation Happens When Class Get Loaded
	// Default Values Get Initialised
	private static final ArrayList<Integer> expirationYear = new ArrayList<>();
	
	// Static Block Will Initilise static Members
	static { 
		// Add the next twenty years to the array list
		int year = LocalDate.now().getYear();
		for (int i = year; i <= year + 20; i++) {
			expirationYear.add(i);
		}   
	}

	private String creditCardName = "";

	public CreditCardForm( String name ) {
		this.creditCardName = name;
	}

	public void sayHello() {
		System.out.println("Hello World!");
	}

	public static void sayGreeting() {
		System.out.println("Good Morning!");
	}

	public void accessTypeMember() {
		System.out.println(expirationYear);
		sayGreeting();
	}

	public static void accessInstanceMember() {
		// System.out.println(creditCardName);        
		// sayHello();
	}


}

// import static java.lang.Math.*;
class StaticImportDemo {
	public static void main(String[] args) {
		double x = 3;
		double y = 4;
		double hypothenuse = sqrt(pow(x, 2) + pow(y, 2)); // i.e., Math.sqrt, Math.pow
		System.out.println(hypothenuse);        
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.ArrayList;

class Network { // Enclosing Class/Context
	private int something;
	// Enclosed Class/Context 
	//      Class Defined Inside Class
	//      By Default It's Inner Class

	//      Member Class is an Inner Class of Network
	public class Member { // Enclosed Class/Context
		private String name;
		private ArrayList<Member> friends = new ArrayList<>();

		public Member(String name) {
			this.name = name;
		}

		public void deactivate() {
			members.remove(this);
		}

		public void addFriend(Member newFriend) {
			friends.add(newFriend);
		}

		public boolean belongsTo(Network n) {
			return Network.this == n;
		}
		
		public String toString() {
			System.out.println(something);
			StringBuilder result = new StringBuilder(name);
			result.append(" with friends ");
			for (Member friend : friends) {
				result.append(friend.name);
				result.append(", ");
			}
			return result.subSequence(0, result.length() - 2).toString();
		}
	}

	private ArrayList<Member> members = new ArrayList<>();

	public Member enroll(String name) {
		Member newMember = new Member(name);
		members.add(newMember);
		return newMember;
	}

	public String toString() {
		return members.toString();
	}
}


class NetworkDemo {
	public static void playWithInnerClasses() {
		Network myFace = new Network();
		Network tooter = new Network();
		Network.Member fred = myFace.enroll("Fred");
		Network.Member wilma = myFace.new Member("Wilma");
			// An object, but not enrolled
			// Make the constructor private to avoid this
		fred.addFriend(wilma);

		Network.Member barney = tooter.enroll("Barney");
		fred.addFriend(barney);
		System.out.println(myFace);
			// If it shouldn't be possible to add a friend
			// from another network, call belongsTo
		System.out.println(barney.belongsTo(myFace));
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Invoice {
	private int something;

	private static class Item { // Item is nested inside Invoice
		String description;
		int quantity;
		double unitPrice;

		double price() { return quantity * unitPrice; }
		public String toString() { 
			// System.out.println(something);
			return quantity + " x " + description + " @ $" + unitPrice + " each";
		}
	}

	private ArrayList<Item> items = new ArrayList<>();
	
	public void addItem(String description, int quantity, double unitPrice) {
		Item newItem = new Item();
		newItem.description = description;
		newItem.quantity = quantity;
		newItem.unitPrice = unitPrice;
		items.add(newItem);
	}
	
	public void print() {
		double total = 0;
		for (Item item : items) {
			System.out.println(item);
			total += item.price();
		}
		System.out.println(total);
	}
}

class InvoiceDemo {
	public static void playWithNestedClass() {
		Invoice invoice = new Invoice();
		invoice.addItem("Blackwell Toaster", 2, 24.95);
		invoice.addItem("ZapXpress Microwave Oven", 1, 49.95);
		invoice.print();
	}
}


//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaObjectOrientedProgramming {
	public static void main( String[] args ) {
		System.out.println("\nFunction : EmployeeDemo.playWithEmployee");
		EmployeeDemo.playWithEmployee();
		
		System.out.println("\nFunction : StaticMethodDemo.playWithClassMembers");
		StaticMethodDemo.playWithClassMembers();

		System.out.println("\nFunction : EmployeeDemo1.playWithEmployee");
		EmployeeDemo1.playWithEmployee();

		System.out.println("\nFunction : NetworkDemo.playWithInnerClasses");
		NetworkDemo.playWithInnerClasses();

		System.out.println("\nFunction : InvoiceDemo.playWithNestedClass");
		InvoiceDemo.playWithNestedClass();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
