#include <stdio.h>
#include <limits.h>

//_____________________________________________________

// BAD CODE
int unsafeSum(int a, int b) {
	return a + b;
}

//_____________________________________________________

signed int summation(signed int a, signed int b) {
	  signed int result = 0;
	  if (((b > 0) && (a > (INT_MAX - b))) ||
	      ((b < 0) && (a < (INT_MIN - b)))) {
		  	printf("Can't Caculate Sum For Given Values");
	  } else {
		    result = a + b;
	  }
    return result;
}

//_____________________________________________________
//_____________________________________________________

void playWithSum() {
	int result = 0;
	int x, y;

	x = 10;
	y = 30;
	result = unsafeSum(x, y);
	printf("\nResult : %d", result);

	x = 2147483647;
	y = 2;
	result = unsafeSum(x, y);
	printf("\nResult : %d", result);
}

//_____________________________________________________

void playWithTypes() {
	int i = 65;
	float f = 3.1234456789;
	printf("\n%d %c", i, i);
// 65 A

	printf("\n%f", f);	
// 3.123446
}

void playWithCharTypes() {
	char ch = 0;

	for( ; ch < 128 ; ch++ ) {
		printf(".");
	}
}

//_____________________________________________________
// Choices
// RTE Same Different

void doChange(int a[], int size) {
	for ( int i = 0 ; i < size ; i++ ) {
		a[i] = 111;
	}
}

void printArray(int a[], int size) {
	for ( int i = 0 ; i < size ; i++ ) {
		printf("\n %d ", a[i]);
	}
}

void playWithDoChange() {
	int numbers[5] = { 10, 20, 30, 40, 50 };

	printArray( numbers, 5 );
	doChange( numbers, 5 );
	printArray( numbers, 5 );
}


//_____________________________________________________

void doDance() {
	printf("\n Doing Dance...!!!");
}

int doDanceAgain(int dance, float something) {
	printf("\n Doing Dance...!!!");
}

void playWithDoDance() {
	// Defining dance Variable
	void (*dance)();

	dance = doDance;
	dance();

	// dance = doDanceAgain;
	// dance();	
}

//_____________________________________________________

// Function Type
//		(int, int) -> int
int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }
int mul(int x, int y) { return x * y; }

// Function Type
//		(int, int, int) -> int
int sum3(int x, int y, int z) { return x + y + z; }

// Polymorphic Function
//		Mechanism : Passing Behaviour To Behaviour
// Function Type
//		(int, int, (int, int) -> int )  -> int
int calculator(int x, int y, int (*operation)(int, int) ) {
	return operation(x, y);
}

void playWithCalculator() {
	int a = 40, b = 20, result = 0;

						// Configuring Calculator
	result = calculator(a, b, sum);
	printf("\nResult : %d", result);

						// Configuring Calculator
	result = calculator(a, b, sub);
	printf("\nResult : %d", result);	

	result = calculator(a, b, mul);
	printf("\nResult : %d", result);	

	// result = calculator(a, b, sum3);
	// printf("\nResult : %d", result);	

	int (*something)(int, int);

	int * ptr = &a;
	// something = ptr;

	something = sum;
	result = something(100, 200);
	printf("\nResult : %d", result);		
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

int main(int argc, char * argv[]) {

	printf("\nArguments Count: %d", argc);

	for( int i  = 0 ; i < argc ; i++ ) {
		printf("\n Arguments: %s", argv[i] );
	}

	printf("\n\nFunction : playWithSum");
	playWithSum();

	printf("\n\nFunction : playWithTypes");
	playWithTypes();

	// printf("\n\nFunction : playWithCharTypes");
	// playWithCharTypes();
	
	printf("\n\nFunction : playWithDoChange");
	playWithDoChange();

	printf("\n\nFunction : playWithDoDance");
	playWithDoDance();

	printf("\n\nFunction : playWithCalculator");
	playWithCalculator();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}

