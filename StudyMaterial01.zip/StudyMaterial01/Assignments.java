_________________________________________________________________

DAY 01
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chater 02: Types, Operators And Expressions
		Chater 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

	Assignment A3 : Coding and Experimenation Assignments
		Practice and Experiment Java Code Till Now Done!!
		
_________________________________________________________________

DAY 02
_________________________________________________________________


_________________________________________________________________

DAY 03
_________________________________________________________________


_________________________________________________________________

DAY 04
_________________________________________________________________


_________________________________________________________________

DAY 05
_________________________________________________________________


_________________________________________________________________

DAY 06
_________________________________________________________________
