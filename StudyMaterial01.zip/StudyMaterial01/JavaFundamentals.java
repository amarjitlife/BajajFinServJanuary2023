/*
javac JavaFundamentals.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaFundamentals
*/
package learnJava;

import java.util.Random;

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Hello {
	public static void sayHello( ) {
		System.out.println("Hello World!!!!");
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class NumberDemo {
	public static void playWithNumbers() {
        System.out.println(4000000); // long literal
        System.out.println(4000000000L); // long literal
	    System.out.println(0xCAFEBABE); // hex literal
        System.out.println(0b1001); // binary literal
        System.out.println(011); // octal literal

        // Underscores in literals   
        System.out.println(1_000_000_000); 
        System.out.println(0b1111_0100_0010_0100_0000);        

        System.out.println(3.14); // double Type
        System.out.println(3.14F); // Float Type
        System.out.println(3.14); // double literal
        System.out.println(3.14D); // double literal
        System.out.println(0x1.0p-3); // hex double literal        
	
        System.out.println(1.0 / 0.0); // Infinity
        System.out.println(-1.0 / 0.0); // -Infinity
        System.out.println(0.0 / 0.0); // NaN

		// BAD CODE
        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);        
        System.out.println(0.0 / 0.0 == Double.NaN);
        // true
		// true
		// false
        // Suppose Following Values Are Coming From Somewhere Else...
        double someting = 0.0;
        double sometingElse = 0.0;

        // Huge Vulnerability!!!
        if ( someting / sometingElse == Double.NaN ) {
        	System.out.println("Don't Allow Access");
        } else {
        	System.out.println("Allow Access");        	
        }

        // GOOD CODE
        System.out.println(Double.isInfinite(1.0 / 0.0));
        System.out.println(Double.isInfinite(-1.0 / 0.0));
        System.out.println(Double.isNaN(0.0 / 0.0));
        System.out.println(Double.isFinite(0.0 / 0.0));
		// true
		// true
		// true
		// false

        someting 	 = 2.0;
        sometingElse = 1.1;
        System.out.println(2.0 - 1.1);
        // BAD PRACTICE
        //		Never Ever Compare Floating Points With Equality
        if ( someting - sometingElse == 0.9 ) {
        	System.out.println("Hi Hi!!!");
        } else {
        	System.out.println("Ho Ho!!!");
        }

        // float f1;
        // float f2;
        // // Bad Code
        // if ( f1 == f2 ) { } else {}

        // // GOOD CODE
        // if ( f1 - f2 <= Epsilon ) { } else { }

        // Character literals
        System.out.println('J'); 
        System.out.println('J' == 74); 
        System.out.println('\u004A'); 
        System.out.println('\u263A');

        // U+1F496
        // System.out.println('\u1F496');
        //2660
        System.out.println('\u2660');
        System.out.println('\u2661');
        System.out.println('\u2662');
        System.out.println('\u2663');
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.Random;

class VariableDemo {
    public static final int DAYS_PER_YEAR = 365;
    
    enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN };
    
    public static void playWithVariables() {
        int total = 0;
        int i = 0, count;
        Random generator = new Random();
        double lotsa$ = 1000000000.0; // Legal, but not a good idea
        double élévation = 0.0;
        double π = 3.141592653589793;
        String Count = "Dracula"; // Not the same as count
        int countOfInvalidInputs = 0; // Example of camelCase
        final int DAYS_PER_WEEK = 7;
        Weekday startDay = Weekday.MON;

        System.out.println( lotsa$ );
        System.out.println( élévation );
        System.out.println( π );
        System.out.println( total );
        System.out.println( Count );
        System.out.println( DAYS_PER_WEEK );                     
        System.out.println( startDay );                     
	    // System.out.println( count );  
	}
}

//_____________________________________________________

class ArithmeticDemo {
    public static void playWithOperations() {
        // Division and remainder
        System.out.println(17 / 5);
        System.out.println(17 % 5);
        System.out.println(Math.floorMod(17, 5));
        
        System.out.println(-17 / 5);
        System.out.println(-17 % 5);
        System.out.println(Math.floorMod(-17, 5));
        
        // Increment and decrement
        int[] a = { 17, 29 };
        int n = 0;
        System.out.printf("%d %d\n", a[n++], n); 
        n = 0;
        System.out.printf("%d %d\n", a[++n], n);
        
        // Powers and roots
        System.out.println(Math.pow(10, 9));
        System.out.println(Math.sqrt(1000000));
        
        // Number conversions
        double x = 42;
        System.out.println(x); // 42.0
        
        float f = 123456789;
        System.out.println(f); // 1.23456792E8
        
        x = 3.75;
        n = (int) x;
        System.out.println(n); // 3
        
        n = (int) Math.round(x); 
        System.out.println(n); // 4
        
        System.out.println('J' + 1); // 75
        char next = (char)('J' + 1); 
        System.out.println(next); // 'K'
        
        n = (int) 3000000000L; 
        System.out.println(n); // -1294967296
    }
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaFundamentals {
	public static void main( String[] args ) {
		System.out.println("\nFunction : Hello.sayHello");
		Hello.sayHello();

		System.out.println("\nFunction : NumberDemo.playWithNumbers");
		NumberDemo.playWithNumbers();

		System.out.println("\nFunction : VariableDemo.playWithVariables");
		VariableDemo.playWithVariables();

		System.out.println("\nFunction : ArithmeticDemo.playWithOperations");
		ArithmeticDemo.playWithOperations();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
