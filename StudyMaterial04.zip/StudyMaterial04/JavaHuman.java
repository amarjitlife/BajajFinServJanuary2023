/*
javac JavaHuman.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaHuman
*/
package learnJava;

// What To Do!
interface Superpower {
	public void fly();
	public void saveWorld();
}

// Creating Type of Type Relationship
//		Mechanism : Using Interfaces
//			Human Type Is Type Of Supower Type
class Spiderman implements Superpower {
	public void fly() {
		System.out.println("Fly Like Spiderman!");
	}

	public void saveWorld() {
		System.out.println("Save World Like Spiderman!");
	}
}

class Superman implements Superpower {
	public void fly() {
		System.out.println("Fly Like Superman!");
	}

	public void saveWorld() {
		System.out.println("Save World Like Superman!");
	}
}

class Batman {
	public void fly() {
		System.out.println("Fly Like Batman!");
	}

	public void saveWorld() {
		System.out.println("Save World Like Batman!");
	}
}

class Wonderwoman {
	public void fly() {
		System.out.println("Fly Like Wonderwoman!");
	}

	public void saveWorld() {
		System.out.println("Save World Like Wonderwoman!");
	}
}

class Heman implements Superpower {
	public void fly() {
		System.out.println("Fly Like Heman!");
	}

	public void saveWorld() {
		System.out.println("Save World Like Heman!");
	}
}

// Creating Type of Type Relationship
//		Mechanism : Inheritance
//			Human Type Is Type Of Wonderwoman Type

// class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Batman {
class HumanDesign1 extends Wonderwoman {
	public void fly() 		{ super.fly(); }
	public void saveWorld() { super.saveWorld(); }
}

// Composition
//		Alternative To Inheritance
class HumanDesign2 {
	Superman power = new Superman();
	public void fly() 		{ power.fly(); }
	public void saveWorld() { power.saveWorld(); }
}

// DESIGN PRINCIPLES
//		Design Towards Abstract Types 
//		Corollary:
//			Design Towards Intefaces Rather Than Concrete Classes

// Polymorphic Human Type
// Creating Type of Type Relationship
//		Mechanism : Composition
//			Human Type Composed Of Superpower Type
class HumanDesign3 {
	Superpower power = null;
	public void fly() 		{ if( power != null ) power.fly(); }
	public void saveWorld() { if( power != null ) power.saveWorld(); }
}

class JavaHuman {
	public static void main(String[] args) {
		HumanDesign1 human1 = new HumanDesign1();
		human1.fly();
		human1.saveWorld();

		HumanDesign2 human2 = new HumanDesign2();
		human2.fly();
		human2.saveWorld();

		HumanDesign3 human3 = new HumanDesign3();
		human3.power = new Superman();
		human3.fly();
		human3.saveWorld();

		human3.power = new Spiderman();
		human3.fly();
		human3.saveWorld();

		human3.power = new Heman();
		human3.fly();
		human3.saveWorld();
	} 
}

