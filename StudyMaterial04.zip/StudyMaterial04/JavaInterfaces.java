/*
javac JavaInterfaces.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaInterfaces
*/
package learnJava;

import java.util.Arrays;
import java.util.Comparator;

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// What It Will Do!
interface IntSequence {
	boolean hasNext();
	int next();
}

// How, When, Where, Which Way To Do!
// error: DigitalSequence is not abstract and 
// does't override abstract method next() in IntSequence
class DigitalSequence implements IntSequence {
	public boolean hasNext() {
		System.out.println("DigitalSequence: Has Next...");
		return true;
	}

	public int next() {        
		System.out.println("DigitalSequence: Next...");
		return 1;
	}
}

class SquareSequence implements IntSequence {
	public boolean hasNext() {
		System.out.println("SquareSequence: Has Next...");
		return true;
	}

	public int next() {        
		System.out.println("SquareSequence: Next...");
		return 1;
	}
}

class IntSequenceDemo {
	// public static void consumeSequence( DigitalSequence digits ) {
	//     digits.hasNext();
	//     digits.next();
	// }

	// public static void consumeSequence( SquareSequence digits ) {
	//     digits.hasNext();
	//     digits.next();
	// }

	// Polymorphic Function
	//      Mechanism : Using Interface
	public static void consumeSequence( IntSequence digits ) {
		digits.hasNext();
		digits.next();
	}

	public static void playWithSequence() {
		DigitalSequence digits = new DigitalSequence();
		consumeSequence( digits );
	
		SquareSequence squares = new SquareSequence();
		consumeSequence( squares );
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface IntSequence1 {
	boolean hasNext();
	int next();
}

class DigitSequence1 implements IntSequence1 {
	private int number;

	public DigitSequence1(int n) {
		number = n;
	}

	public boolean hasNext() {
		return number != 0;
	}

	public int next() {
		int result = number % 10;
		number /= 10;
		return result;
	}
	
	public int rest() {
		return number;
	}
}

class SquareSequence1 implements IntSequence1 {
	private int i;

	public boolean hasNext() {
		return true;
	}

	public int next() {
		i++;
		return i * i;
	}
}

class IntSequenceDemo1 {
	public static double average(IntSequence1 seq, int n) {
		int count = 0;
		double sum = 0;
		while (seq.hasNext() && count < n) {
			count++;
			sum += seq.next();
		}
		return count == 0 ? 0 : sum / count;
	}

	public static void playWithInterfaces() {
		SquareSequence1 squares = new SquareSequence1();
		double avg = average(squares, 100);
		System.out.println("Average of first 100 squares: " + avg);
		
		IntSequence1 digits = new DigitSequence1(1729);
		while (digits.hasNext()) System.out.print(digits.next() + " ");
		System.out.println();
		
		digits = new DigitSequence1(1729);
		avg = average(digits, 100);
			// Will only look at the first four sequence values
		System.out.println("Average of the digits: " + avg);
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Identified {
	default int getId() { return Math.abs( hashCode()); }
}

interface Person {
	String getName();
	default int getId() { return 0; }
}

class Employee implements Person, Identified {
	private int id = 111;
	private String name;
	private double salary;

	public Employee(String name, double salary) {
		this.name = name;
		this.salary = salary;
	}

	public void raiseSalary(double byPercent) {
		double raise = salary * byPercent / 100;
		salary = salary + raise;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return Identified.super.getId() + Person.super.getId();
		// return id; 
	}
}

class EmployeeDemo {
	public static void playWithEmployee() {
		Employee gabbar = new Employee("Gabbar Singh", 50000);
		gabbar.raiseSalary( 100.0 );

		System.out.println( gabbar.getName() );
		System.out.println( gabbar.getId() );
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Employee1 implements Comparable<Employee1> {
    private String name;
    private double salary;
        
    public Employee1(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    
    public Employee1(double salary) {
        this.name = "";
        this.salary = salary;
    }        
    
    public Employee1(String name) {
        // salary automatically set to zero
        this.name = name;
    } 
    
    public Employee1() {
        this("", 0);
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int compareTo(Employee1 other) {
        return Double.compare(salary, other.salary);
    }
}

class EmployeeDemo1 {
	public static void playWithEmployee() {
		Employee1 gabbar = new Employee1("Gabbar Singh", 50000);
		gabbar.raiseSalary( 100.0 );
		System.out.println( gabbar.getName() );
		System.out.println( gabbar.getSalary() );

		Employee1 thakur = new Employee1("Thakur", 500000);
		System.out.println( thakur.getName() );
		System.out.println( thakur.getSalary() );

		System.out.println( gabbar.compareTo( thakur ) );
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.Arrays;
// import java.util.Comparator;

class LengthComparator implements Comparator<String> {
    public int compare(String first, String second) {
        return first.length() - second.length();
    }
}

class SortDemo {
    public static void playWithComparator() {
        String[] friends = { "Peter", "Paul", "Mary" };
        Arrays.sort(friends); // friends is now ["Mary", "Paul", "Peter"]
        System.out.println(Arrays.toString(friends));
        
        friends = new String[] { "Peter", "Paul", "Mary" };
        Arrays.sort(friends, new LengthComparator());
        System.out.println(Arrays.toString(friends));
    }
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaInterfaces {
	public static void main( String[] args ) {
		System.out.println("\nFunction : IntSequenceDemo.playWithSeqeunce");
		IntSequenceDemo.playWithSequence();

		System.out.println("\nFunction : IntSequenceDemo1.playWithInterfaces");
		IntSequenceDemo1.playWithInterfaces();

		System.out.println("\nFunction : EmployeeDemo.playWithEmployee");
		EmployeeDemo.playWithEmployee();

		System.out.println("\nFunction : EmployeeDemo1.playWithEmployee");
		EmployeeDemo1.playWithEmployee();

		System.out.println("\nFunction : SortDemo.playWithComparator");
		SortDemo.playWithComparator();
		
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!
