#include <stdio.h>

int main() {
	int *ptr = NULL;
	
	int value = *ptr;
}

