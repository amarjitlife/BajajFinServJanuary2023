/**** Run Following Commands
kotlinc KotlinFunctionsLambda.kt -include-runtime -d lambda.jar
java -jar lambda.jar
****/
package learnKotlin

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// Function Type
//		(Int, Int) -> Int
fun sum(a: Int, b: Int) : Int = a + b
fun sub(a: Int, b: Int) : Int = a - b

// Polymorphic Function
// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int
fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 40
	val b = 20
	var result: Int

	result = calculator(a, b, ::sum)
	println("Result : $result")

	result = calculator(a, b, ::sub)
	println("Result : $result")

	// Lambda Expression
	// error: type mismatch: inferred type is (Int, Int) -> Int 
	// but Int was expected 
	// val sumLambda: Int = { x: Int, y: Int -> x + y }

	val sumLambda1  = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambda1)
	println("Result : $result")

	val sumLambda2 : (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator(a, b, sumLambda2)
	println("Result : $result")

	val subLambda = { x: Int, y: Int -> x - y }
	result = calculator(a, b, subLambda)
	println("Result : $result")

	result = calculator(a, b, { x: Int, y: Int -> x + y })
	println("Result : $result")

	result = calculator(a, b, { x: Int, y: Int -> x - y })
	println("Result : $result")

	// Type Of something
	//		(Int, Int) -> Int
	// error: type mismatch: inferred type is KFunction2<Int, Int, Int> 
	// but Int was expected
	// val something: Int = ::sum
	val something1 = ::sum
	result = something1(a, b)
	println("Result : $result")

	val something2: (Int, Int) -> Int = ::sum
	result = something2(a, b)
	println("Result : $result")

	// error: type mismatch: inferred type is 
	//		KFunction3<Int, Int, (Int, Int) -> Int, Int> 
	//      but (Int, Int) -> Int was expected
	// var somethingAgain : (Int, Int) -> Int = ::calculator
	// result = somethingAgain(a, b)
	// println("Result : $result")	

	var somethingAgain1 = ::calculator
	result = somethingAgain1(a, b, ::sum)
	println("Result : $result")	

	var somethingAgain2: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	result = somethingAgain2(a, b, ::sum)
	println("Result : $result")	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

data class Person(val name: String, val age: Int)

fun findTheOldest(persons: List<Person>) {
	var maxAge = 0
	var theOldest: Person? = null

	for( person in persons ) {
		if ( person.age > maxAge ) {
			maxAge = person.age
			theOldest = person 
		}
	}
	println( theOldest )
}

fun playWithPersons() {
	val persons = listOf( Person("Gabbar Singh", 35), Person("Basanti", 24),
	 	Person("Veeru", 27), Person("Jay", 25) )
	findTheOldest( persons )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithLambdas() {
	// What Is Type Of something

	val something: () -> Unit = { println(42) }
	something()

	val persons = listOf( Person("Alice", 20), Person("Gabbar", 35), 
		Person("Basanti", 24), Person("Veeru", 27), Person("Jay", 25) )

	val names = persons.joinToString( separator = " ", 
						transform = { person: Person -> person.name } 
					)
	println(names)

	var lambdaResult: Int
	var multiplyLambda : (Int, Int) -> Int

	val multiplyLambda0 = { a: Int, b: Int -> a * b }
	lambdaResult = multiplyLambda0( 10, 20 )
	println( lambdaResult )

	multiplyLambda = { a: Int, b: Int -> Int
		a * b
	}

	lambdaResult = multiplyLambda( 10, 20 )
	println( lambdaResult )

	multiplyLambda = { a, b -> 
		a * b
	}

	lambdaResult = multiplyLambda( 10, 20 )
	println( lambdaResult )

	var doubleLamda = { a: Int -> a * 2 }
	lambdaResult = doubleLamda( 25 )
	println( lambdaResult )

	doubleLamda = { it * 2 }
	lambdaResult = doubleLamda( 25 )
	println( lambdaResult )

	val square1 = { number : Int -> number * number }
	lambdaResult = square1( 25 )
	println( lambdaResult )

	// val square2 = { it * it }
	val square2: (Int) -> Int = { it * it }
	lambdaResult = square2( 25 )
	println( lambdaResult )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun playWithLambdasAgain() {
	var result : Int

	// Higher Order Functions
	//		Function Which Takes Function Argument
	fun operate(a: Int, b: Int, operation: (Int, Int) -> Int): Int {
		val result = operation(a, b)
		return result
	}

	val addLambda = { a: Int, b: Int -> a + b }
	result = operate( 40, 20, operation = addLambda )
	println( result )

	fun addFunction(a: Int, b: Int) = a + b
	result = operate( 40, 20, operation = ::addFunction )
	println( result )	

	result = operate( 40, 20, operation = Int::plus )
	println( result )	

	result = operate( 40, 20, operation = { a: Int, b: Int -> a + b } )
	println( result )	

	result = operate( 40, 20, 
		operation = { a: Int, b: Int -> 
			a + b 
		} 
	)
	println( result )	

	result = operate( 40, 20, 
		operation = { a, b -> 
			a + b 
		} 
	)
	println( result )	

	result = operate( 40, 20, operation = { a, b -> a + b } )
	println( result )	

	result = operate( 40, 20, { a, b -> a + b } )
	println( result )	

	// Trailing Lambda
	result = operate( 40, 20 ) { a, b -> a + b } 
	println( result )	
			 // operate Logic
	result = operate( 40, 20 ) { // Extended Logic 
		a, b -> a + b 
	} 
	println( result )
	
}

//_____________________________________________________

// Higher Order Functions
//		Functions Which Takes And/Or Returns Functions

// Function Type
//		(Boolean) -> (Int) -> Int
fun chooseSteps(backward: Boolean) : (Int) -> Int {
	// Function Type
	//		(Int) -> Int	
	fun moveForward(start: Int) : Int { return start + 1 }
	fun moveBackward(start: Int): Int { return start - 1 }

	return if ( backward ) ::moveBackward else ::moveForward
}

fun playWithChooseStepFunction() {
	// What Is The Type Of Something
	val something: (Int) -> Int = chooseSteps( backward = true )
	var somethingAgain: (Boolean) -> (Int) -> Int = ::chooseSteps
	val somethingMore = something(10)
	
	val somethingOnceMore = somethingAgain(true)
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main( ) {
	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithPersons")
	playWithPersons()

	println("\nFunction : playWithLambdas")
	playWithLambdas()

	println("\nFunction : playWithLambdasAgain")
	playWithLambdasAgain()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
