import sys

fileNames = sys.argv[1:]

words = {}

for fileName in fileNames:
	for line in open(fileName):
		for word in line.split():
			if len( word ) >= 2:
				words[word] = words.get(word, 0) + 1

for word in words.items():
	print(word)
