/*//_______________________________________________
javac Hello.java -d ClassFiles
java -cp ClassFiles/ learnJava.Hello

//_______________________________________________
codebunk.com

class Main {
	public static void main( String[] args ) {
		System.out.println("Hello World!!!!");
	}
}
*/

package learnJava;

public class Hello {
	public static void main( String[] args ) {
		System.out.println("Hello World!!!!");
	}
}
