/*
javac JavaFundamentals.java -d ClassFiles
java -cp ClassFiles/ learnJava.JavaFundamentals
*/
package learnJava;

import java.util.Random;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class Hello {
	public static void sayHello( ) {
		System.out.println("Hello World!!!!");
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

class NumberDemo {
	public static void playWithNumbers() {
        System.out.println(4000000); // long literal
        System.out.println(4000000000L); // long literal
	    System.out.println(0xCAFEBABE); // hex literal
        System.out.println(0b1001); // binary literal
        System.out.println(011); // octal literal

        // Underscores in literals   
        System.out.println(1_000_000_000); 
        System.out.println(0b1111_0100_0010_0100_0000);        

        System.out.println(3.14); // double Type
        System.out.println(3.14F); // Float Type
        System.out.println(3.14); // double literal
        System.out.println(3.14D); // double literal
        System.out.println(0x1.0p-3); // hex double literal        
	
        System.out.println(1.0 / 0.0); // Infinity
        System.out.println(-1.0 / 0.0); // -Infinity
        System.out.println(0.0 / 0.0); // NaN

		// BAD CODE
        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);        
        System.out.println(0.0 / 0.0 == Double.NaN);
        // true
		// true
		// false
        // Suppose Following Values Are Coming From Somewhere Else...
        double someting = 0.0;
        double sometingElse = 0.0;

        // Huge Vulnerability!!!
        if ( someting / sometingElse == Double.NaN ) {
        	System.out.println("Don't Allow Access");
        } else {
        	System.out.println("Allow Access");        	
        }

        // GOOD CODE
        System.out.println(Double.isInfinite(1.0 / 0.0));
        System.out.println(Double.isInfinite(-1.0 / 0.0));
        System.out.println(Double.isNaN(0.0 / 0.0));
        System.out.println(Double.isFinite(0.0 / 0.0));
		// true
		// true
		// true
		// false

        someting 	 = 2.0;
        sometingElse = 1.1;
        System.out.println(2.0 - 1.1);
        // BAD PRACTICE
        //		Never Ever Compare Floating Points With Equality
        if ( someting - sometingElse == 0.9 ) {
        	System.out.println("Hi Hi!!!");
        } else {
        	System.out.println("Ho Ho!!!");
        }

        // float f1;
        // float f2;
        // // Bad Code
        // if ( f1 == f2 ) { } else {}

        // // GOOD CODE
        // if ( f1 - f2 <= Epsilon ) { } else { }

        // Character literals
        System.out.println('J'); 
        System.out.println('J' == 74); 
        System.out.println('\u004A'); 
        System.out.println('\u263A');

        // U+1F496
        // System.out.println('\u1F496');
        //2660
        System.out.println('\u2660');
        System.out.println('\u2661');
        System.out.println('\u2662');
        System.out.println('\u2663');
	}
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// import java.util.Random;

class VariableDemo {
    public static final int DAYS_PER_YEAR = 365;
    
    enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN };
    
    public static void playWithVariables() {
        int total = 0;
        int i = 0, count;
        Random generator = new Random();
        double lotsa$ = 1000000000.0; // Legal, but not a good idea
        double élévation = 0.0;
        double π = 3.141592653589793;
        String Count = "Dracula"; // Not the same as count
        int countOfInvalidInputs = 0; // Example of camelCase
        final int DAYS_PER_WEEK = 7;
        Weekday startDay = Weekday.MON;

        System.out.println( lotsa$ );
        System.out.println( élévation );
        System.out.println( π );
        System.out.println( total );
        System.out.println( Count );
        System.out.println( DAYS_PER_WEEK );                     
        System.out.println( startDay );                     
	    // System.out.println( count );  
	
        String नमस = "Hello";
        System.out.println( नमस );                     

    }
}

//_____________________________________________________

class ArithmeticDemo {
    public static void playWithOperations() {
        // Division and remainder
        System.out.println(17 / 5);
        System.out.println(17 % 5);
        System.out.println(Math.floorMod(17, 5));
        
        System.out.println(-17 / 5);
        System.out.println(-17 % 5);
        System.out.println(Math.floorMod(-17, 5));
        
        // Increment and decrement
        int[] a = { 17, 29 };
        int n = 0;
        System.out.printf("%d %d\n", a[n++], n); 
        n = 0;
        System.out.printf("%d %d\n", a[++n], n);
        
        // Powers and roots
        System.out.println(Math.pow(10, 9));
        System.out.println(Math.sqrt(1000000));
        
        // Number conversions
        double x = 42;
        System.out.println(x); // 42.0
        
        float f = 123456789;
        System.out.println(f); // 1.23456792E8
        
        x = 3.75;
        n = (int) x;
        System.out.println(n); // 3
        
        n = (int) Math.round(x); 
        System.out.println(n); // 4
        
        System.out.println('J' + 1); // 75
        char next = (char)('J' + 1); 
        System.out.println(next); // 'K'
        
        n = (int) 3000000000L; 
        System.out.println(n); // -1294967296
    }
}

//_____________________________________________________

// import java.math.BigDecimal;
// import java.math.BigInteger;

class BigNumberDemo {
    public static void playWithBigNumbers() {
        BigInteger n = BigInteger.valueOf(876543210123456789L);
        BigInteger k = new BigInteger("9876543210123456789");
        BigInteger r = BigInteger.valueOf(5).multiply(n.add(k)); // r = 5 * (n + k)
        System.out.println(r);
        System.out.println(2.0 - 1.1);
        BigDecimal d = BigDecimal.valueOf(2, 0).subtract(BigDecimal.valueOf(11, 1));
        System.out.println(d);
    }
}

//_____________________________________________________

class RelationalDemo {
    public static void playWithRelationalOperators() {
        int length = 10;
        int n = 7;
        System.out.println(0 <= n && n < length);
        
        // Short circuit evaluation
        int s = 30;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        n = 0;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        System.out.println(n == 0 || s + (1 - s) / n >= 50);
        
        int time = 7;
        System.out.println(time < 12 ? "am" : "pm");
    }
}

//_____________________________________________________

// import java.time.ZoneId;
// import java.util.Arrays;

class StringDemo {
    public static void playWithStrings() {
        String location = "Java";
        String greeting = "Hello " + location;

        System.out.println(greeting);
        int age = 42;
        String output = age + " years";
        System.out.println(output);
        
        System.out.println("Next year, you will be " + age + 1); // Error
        System.out.println("Next year, you will be " + (age + 1)); // Ok
        
        String names = String.join(", ", "Peter", "Paul", "Mary");
        System.out.println(names);

        StringBuilder builder = new StringBuilder();

        for (String id : ZoneId.getAvailableZoneIds()) {
            builder.append(id);
            builder.append(", ");
        }
        String result = builder.toString();
        // System.out.println(result);
        System.out.println(result.substring(0, 200) + "...");
        System.out.println(result.length());

        // Substring
        String helloWorld = "Hello, World!";
        String world = helloWorld.substring(7, 12); // [7, 12)
        System.out.println(world);        
    
        System.out.println( world.equals("World") );
        System.out.println( world == "World" );
        System.out.println( world == "World!" );
        System.out.println( helloWorld == "Hello, World!" );
// false
// false
// true
    }
}

//_____________________________________________________

// import java.util.Arrays;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.Collections;

class ArrayDemo {
    public static void playWithArrays() {
        String[] names = new String[10];
        // String * names = ( String * ) malloc( 10 * sizeof(String) );

        for (int i = 0; i < names.length / 2; i++) {
            names[i] = "";
        }

        System.out.println("names="+Arrays.toString(names));
        names[0] = "Fred";
        names[1] = names[0];
    
        System.out.println("names="+Arrays.toString(names));
        String[] namesAgain = names;
        System.out.println("namesAgain="+Arrays.toString(namesAgain));

        names[0] = "Gabbar Singh";
        System.out.println("names="+Arrays.toString(names));
        System.out.println("namesAgain="+Arrays.toString(namesAgain));

        int[] primes = new int[] { 2, 3, 5, 7, 11, 13 };
        int[] numbers = primes;

        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("numbers: " + Arrays.toString( numbers ));

        primes[5] = 17;
        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("numbers: " + Arrays.toString( numbers ));
    
        primes[5] = 13;
        int [] primesAgain = Arrays.copyOf( primes, primes.length );
        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("primesAgain: " + Arrays.toString( primesAgain ));

        primes[5] = 29;
        System.out.println("primes: " + Arrays.toString( primes ));
        System.out.println("primesAgain: " + Arrays.toString( primesAgain ));
    }

     public static void playWithListDemo() {
        ArrayList<String> friends = new ArrayList<>();
        friends.add("Peter");
        friends.add("Paul");
        friends.remove(1);
        friends.add(0, "Paul"); // Adds before index 0

        System.out.println("friends=" + friends);

        String first = friends.get(0);
        System.out.println("first=" + first);
        friends.set(1, "Mary");

        for (int i = 0; i < friends.size(); i++) {
            System.out.println(friends.get(i));
        }

        ArrayList<String> people = friends;
        people.set(0, "Mary"); 
        System.out.println("friends=" + friends);
        
        ArrayList<String> copiedFriends = new ArrayList<>(friends);
        copiedFriends.set(0, "Fred"); 
        System.out.println("copiedFriends=" + copiedFriends);
        System.out.println("friends=" + friends);

//        ArrayList<int> something = new ArrayList<>();
        // ArrayList<Integer> something = new ArrayList<Integer>();
        ArrayList<Integer> something = new ArrayList<>();
        something.add(10);
        something.add(20);
        something.add(30);
        something.add(40);
        something.add(50);
        //something.add("DING");
        //something.add(90.9);

        for (Integer item: something) {
            System.out.println(item);
        }
        
        friends = new ArrayList<>(Arrays.asList("Peter", "Paul", "Mary"));
        String[] names = friends.toArray(new String[0]);
        
        //String[] names = friends.toArray();
        //ArrayJava.java:96: error: incompatible types: Object[] cannot be converted to String[]
        //String[] names = friends.toArray();
        

        System.out.println("names=" + Arrays.toString(names));               
        
        ArrayList<String> moreFriends = new ArrayList<>(Arrays.asList(names));
        moreFriends.add("Ding Dong");
        System.out.println("moreFriends=" + moreFriends);         
        
        Collections.reverse(friends);
        System.out.println("After reversing, friends=" + friends);
        Collections.shuffle(friends);
        System.out.println("After shuffling, friends=" + friends);
        Collections.sort(friends);        
        System.out.println("After sorting, friends=" + friends);
    }
   
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

public class JavaFundamentals {
	public static void main( String[] args ) {
		System.out.println("\nFunction : Hello.sayHello");
		Hello.sayHello();

		System.out.println("\nFunction : NumberDemo.playWithNumbers");
		NumberDemo.playWithNumbers();

		System.out.println("\nFunction : VariableDemo.playWithVariables");
		VariableDemo.playWithVariables();

		System.out.println("\nFunction : ArithmeticDemo.playWithOperations");
		ArithmeticDemo.playWithOperations();

		System.out.println("\nFunction : BigNumberDemo.playWithBigNumbers");
        BigNumberDemo.playWithBigNumbers();

		System.out.println("\nFunction : RelationalDemo.playWithRelationalOperators");
        RelationalDemo.playWithRelationalOperators();

		System.out.println("\nFunction : StringDemo.playWithStrings");
        StringDemo.playWithStrings();

		System.out.println("\nFunction : ArrayDemo.playWithArrays");
        ArrayDemo.playWithArrays();

		System.out.println("\nFunction : ArrayDemo.playWithListDemo");
        ArrayDemo.playWithListDemo();
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
