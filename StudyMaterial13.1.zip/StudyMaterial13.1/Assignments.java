_________________________________________________________________

DAY 01
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

	Assignment A3 : Coding and Experimenation Assignments
		Practice and Experiment Java Code Till Now Done!!
		
_________________________________________________________________

DAY 02
_________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Coding and Reasoning Assignments
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Java Code Till Now Done!!
	
	Assignment A4 : Write Function To Calculate Factorial of Integer( Z )

_________________________________________________________________

DAY 03
_________________________________________________________________

	Assignment A1.1 : REVISION, Thinking Assignment [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions
		Chapter 05: Pointers and Arrays

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A1.2 : Coding and Thinking Assignment [ MUST MUST ]
		Improve Factorial Program To Take Number From Command Line
		Explore Command Line Arguments In C
			int main( int argc, char *arg[] )

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 03 : Process Description and Control
		Chapter 01 : Computer System Overview
		Chapter 02 : Operating System Overview
		
_________________________________________________________________

DAY 04
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		https://docs.oracle.com/javase/8/docs/api/java/lang/Comparable.html
		https://docs.oracle.com/javase/8/docs/api/java/util/Comparator.html

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 03 : Process Description and Control
		Chapter 01 : Computer System Overview
		Chapter 02 : Operating System Overview

_________________________________________________________________

DAY 05
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

_________________________________________________________________

DAY 06
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A2 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 07
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]
		Chapter 04 : Inheritance and Reflection
		Chapter 05 : Exceptions, Assertions, and Logging
		Chapter 07 : Collections

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 01 : Full Chapter 
		Chapter 02 : Full Chapter
		Chapter 03 : Full Chapter
		Chapter 04 : Till Page 77 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 08
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 03 : Full Chapter
		Chapter 04 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)
		https://docs.oracle.com/javase/7/docs/api/java/lang/Object.html#equals(java.lang.Object)

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!
		
_________________________________________________________________

DAY 09
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 04 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 08 : Streams [ MUST MUST ]
		Chapter 09 : Procesing Inputs and Outputs [ MUST ]

		Reference : Core Java for the Impatient By Cay Horstmann

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!

_________________________________________________________________

DAY 10
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 05 : Full Chapter 
		Chapter 06 : Full Chapter 
		Chapter 07 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 08 : Streams [ MUST MUST ]

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!

_________________________________________________________________

DAY 11
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 05 : Full Chapter 
		Chapter 06 : Full Chapter 
		Chapter 07 : Full Chapter 
		Chapter 08 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 08 : Streams [ MUST MUST ]

	Assignment A3 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!

_________________________________________________________________

DAY 12
_________________________________________________________________

	Assignment A1 : Reading and Thinking Assignment [ MUST MUST ]		
		Chapter 06 : Full Chapter 
		Chapter 07 : Full Chapter 
		Chapter 08 : Full Chapter 

		Reference : Kotlin in Action 1st Edition
			by Dmitry Jemerov  (Author), Svetlana Isakova (Author)

	Assignment A2 : Coding and Experimentation Assignments
		Practice and Experiment Kotlin Code Till Now Done!!


_________________________________________________________________

DAY 13
_________________________________________________________________

	AndroidCode A1 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial12.1.zip And Unzip It!

		Explore Code
			All .java And .xml Files In Following Projects
			└── StudyMaterial12.1
			    └── Android.Code01.1
			        ├── ActivitiesJava
			        ├── ConfigChangesJava
			        ├── ManifestAndResourcesJava


	AndroidCode A2 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial12.2.zip And Unzip It!

			 ├── StudyMaterial12.2
				│ └── Android.Code02.1
				│     ├── Project.04.01.Layouts
				│     ├── Project.04.03.Views
				│     ├── Project.04.04.Adapters

	Coding Assignment CA3 : 
		Write Good And Working Code In Kotlin 
			For Following Android Examples
		
		    └── Android.Code01.1
		        ├── ActivitiesJava

		 Create New Project
		 	Language : Kotlin
		 	minSdk : 28

	Coding Assignment CA4 : 
		Write Good And Working Code In Kotlin 
			For Following Android Examples

		    └── Android.Code01.1
		        ├── ConfigChangesJava
		        ├── ManifestAndResourcesJava

			└── Android.Code02.1
			     ├── Project.04.01.Layouts
			     ├── Project.04.03.Views
						       
	Assignment RA1 : Reading and Thinking Assignment [ MUST MUST ]		
		https://developer.android.com/guide/components/fundamentals
		
_________________________________________________________________

DAY 14
_________________________________________________________________

	AndroidCode A2 : Explore And Understand Android Concepts and Code!
		GitHub Link: https://github.com/amarjitlife/BajajFinServJanuary2023
		Download File: StudyMaterial12.2.zip And Unzip It!

			 ├── StudyMaterial12.2
				│ └── Android.Code02.1
				│     ├── Project.04.04.Adapters

	Coding Assignment CA1 : 
		Write Good And Working Code In Kotlin 
			For Following Android Examples

			 ├── StudyMaterial12.2
				 └── Android.Code02.1
				     ├── Project.04.04.Adapters

	Coding Assignment CA2 : 
		Write Good And Working App Code In Kotlin
			Flowers App
				- List Flowers With Images And Names
				- Structure Your Code In MVC Architecture
				- Create Model, View and Controller Classes/Files

	Coding Assignment CA3 : 
		Write Good And Working App Code In Kotlin
			AndroidIntroduction Example

	Assignment RA1 : Reading and Thinking Assignment [ MUST MUST ]		
		https://developer.android.com/guide/components/fundamentals
		https://guides.codepath.com/android/Activity-Lifecycle		
		https://developer.android.com/guide/components/activities/intro-activities
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/components/activities/state-changes
		https://developer.android.com/guide/components/activities/tasks-and-back-stack
		https://developer.android.com/guide/topics/resources/providing-resources
		https://developer.android.com/guide/topics/resources/runtime-changes
		https://guides.codepath.com/android/Using-an-ArrayAdapter-with-ListView
		https://guides.codepath.com/android/Using-the-RecyclerView

	GitHub Project Naming Guilelines
		Parent GIT Repository Name: LearnAndroid
			After That Each Directory Is Android Project

			LearnAndroid
				LayoutKotlin
				ConfigChangesKotlin
				ViewKotlin
				FlowersAppKotlin
				AndroidIntroductionKotlin


_________________________________________________________________

DAY 15
_________________________________________________________________


_________________________________________________________________

DAY 16
_________________________________________________________________


_________________________________________________________________

DAY 17
_________________________________________________________________


_________________________________________________________________

DAY 18
_________________________________________________________________


_________________________________________________________________

FUTURE WORK
_________________________________________________________________


